package com.lia.htmlstudio

object Templates {
    val names = listOf("html", "game", "blank")

    fun files(template: String): Map<String, String> = when (template) {
        "blank" -> mapOf("index.html" to "<!doctype html>\n<html>\n<head>\n  <meta charset=\"utf-8\">\n  <title>New</title>\n</head>\n<body>\n\n</body>\n</html>\n")
        "game" -> mapOf(
            "index.html" to """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Car Game</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <canvas id="game" width="320" height="480"></canvas>
  <p id="score">Score: 0</p>
  <script src="js/game.js"></script>
</body>
</html>
""",
            "css/style.css" to "body { background: #0d1117; color: #e6edf3; font-family: sans-serif; text-align: center; margin: 0; padding: 12px; }\ncanvas { background: #222; border: 2px solid #3fb950; max-width: 100%; }\n",
            "js/game.js" to """const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
let player = { x: 140, y: 420, w: 40, h: 40 };
let score = 0;

function drawPlayer() {
  ctx.fillStyle = '#3fb950';
  ctx.fillRect(player.x, player.y, player.w, player.h);
}

function update() {
  score++;
  scoreEl.textContent = 'Score: ' + score;
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawPlayer();
}

function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}

canvas.addEventListener('touchmove', function (e) {
  const r = canvas.getBoundingClientRect();
  player.x = Math.max(0, Math.min(canvas.width - player.w, e.touches[0].clientX - r.left - player.w / 2));
  e.preventDefault();
}, { passive: false });
document.addEventListener('keydown', function (e) {
  if (e.key === 'ArrowLeft') player.x = Math.max(0, player.x - 15);
  if (e.key === 'ArrowRight') player.x = Math.min(canvas.width - player.w, player.x + 15);
});

console.log('Game started');
loop();
"""
        )
        else -> mapOf(
            "index.html" to """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>My Project</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <h1>Hello, LIA!</h1>
  <p id="msg">Your HTML project starts here.</p>
  <button id="btn">Test</button>
  <script src="js/app.js"></script>
</body>
</html>
""",
            "css/style.css" to "body {\n  font-family: Arial, sans-serif;\n  background: #101827;\n  color: #ffffff;\n  text-align: center;\n  padding: 30px;\n}\nbutton {\n  padding: 12px 20px;\n  border: 0;\n  border-radius: 10px;\n  background: #28a879;\n  color: #ffffff;\n}\n",
            "js/app.js" to "document.getElementById('btn').addEventListener('click', function () {\n  document.getElementById('msg').textContent = 'It works!';\n  console.log('Button clicked');\n});\n"
        )
    }

    val snippets: List<Pair<String, String>> = listOf(
        "HTML5 boilerplate" to "<!doctype html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"utf-8\">\n  <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n  <title>Title</title>\n</head>\n<body>\n\n</body>\n</html>\n",
        "Flexbox center" to "display: flex;\nalign-items: center;\njustify-content: center;\n",
        "Media query (mobile)" to "@media (max-width: 600px) {\n  \n}\n",
        "CSS grid 3 columns" to "display: grid;\ngrid-template-columns: repeat(3, 1fr);\ngap: 12px;\n",
        "JS event listener" to "element.addEventListener('click', function (e) {\n  \n});\n",
        "JS fetch JSON" to "fetch('data.json')\n  .then(function (r) { return r.json(); })\n  .then(function (data) { console.log(data); })\n  .catch(function (err) { console.error(err); });\n",
        "Canvas game loop" to "function loop() {\n  update();\n  draw();\n  requestAnimationFrame(loop);\n}\nloop();\n",
    )
}
