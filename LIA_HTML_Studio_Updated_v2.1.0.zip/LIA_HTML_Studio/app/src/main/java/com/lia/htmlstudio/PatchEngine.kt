package com.lia.htmlstudio

import org.json.JSONArray
import org.json.JSONObject

class PatchException(val opIndex: Int, message: String) : Exception(message)

/**
 * Targeted, all-or-nothing patching. The caller reads the file, runs [apply] and only writes the result if every
 * operation succeeded. Ambiguous matches are rejected instead of guessed.
 *
 * Operation types:
 *  replace_text     {find, replace, occurrence?: 1-based int | "all"}   (find must be unique unless occurrence given)
 *  insert_after     {anchor, text}      insert text right after the unique anchor
 *  insert_before    {anchor, text}
 *  replace_function {name, text}        replaces a whole JS function/method/arrow function by name (brace matched)
 *  replace_lines    {start, end, text}  1-based inclusive line range
 *  set_css_property {selector, property, value}   edits or adds one declaration (creates the rule if missing)
 *  append / prepend {text}
 */
object PatchEngine {
    fun apply(original: String, ops: JSONArray): String {
        var s = original
        for (i in 0 until ops.length()) {
            val op = ops.optJSONObject(i) ?: throw PatchException(i, "Operation $i is not an object")
            s = when (val type = op.optString("type")) {
                "replace_text" -> replaceText(s, op, i)
                "insert_after" -> insertRel(s, op, i, after = true)
                "insert_before" -> insertRel(s, op, i, after = false)
                "replace_function" -> replaceFunction(s, op, i)
                "replace_lines" -> replaceLines(s, op, i)
                "set_css_property" -> setCss(s, op, i)
                "append" -> s + (if (s.endsWith("\n") || s.isEmpty()) "" else "\n") + req(op, "text", i)
                "prepend" -> req(op, "text", i) + s
                else -> throw PatchException(i, "Unknown operation type '$type'")
            }
        }
        return s
    }

    private fun req(op: JSONObject, key: String, i: Int): String {
        if (!op.has(key)) throw PatchException(i, "Missing field '$key'")
        return op.getString(key)
    }

    private fun indexesOf(s: String, needle: String): List<Int> {
        val r = ArrayList<Int>(); var from = 0
        while (true) { val p = s.indexOf(needle, from); if (p < 0) break; r.add(p); from = p + maxOf(1, needle.length) }
        return r
    }

    private fun replaceText(s: String, op: JSONObject, i: Int): String {
        val find = req(op, "find", i); val rep = req(op, "replace", i)
        if (find.isEmpty()) throw PatchException(i, "'find' must not be empty")
        val hits = indexesOf(s, find)
        if (hits.isEmpty()) throw PatchException(i, "Text to replace was not found: '${find.take(80)}'")
        val occ = op.opt("occurrence")
        return when {
            occ == "all" -> s.replace(find, rep)
            occ is Int -> {
                if (occ < 1 || occ > hits.size) throw PatchException(i, "occurrence $occ out of range (found ${hits.size})")
                s.substring(0, hits[occ - 1]) + rep + s.substring(hits[occ - 1] + find.length)
            }
            hits.size > 1 -> throw PatchException(i, "Text matches ${hits.size} places; add more context or set 'occurrence'/'all'")
            else -> s.substring(0, hits[0]) + rep + s.substring(hits[0] + find.length)
        }
    }

    private fun insertRel(s: String, op: JSONObject, i: Int, after: Boolean): String {
        val a = req(op, "anchor", i); val t = req(op, "text", i)
        val hits = indexesOf(s, a)
        if (hits.isEmpty()) throw PatchException(i, "Anchor not found: '${a.take(80)}'")
        if (hits.size > 1) throw PatchException(i, "Anchor matches ${hits.size} places; make it more specific")
        val p = if (after) hits[0] + a.length else hits[0]
        return s.substring(0, p) + t + s.substring(p)
    }

    private fun replaceLines(s: String, op: JSONObject, i: Int): String {
        val lines = s.split("\n").toMutableList()
        val st = op.optInt("start", -1); val en = op.optInt("end", st)
        if (st < 1 || en < st || en > lines.size) throw PatchException(i, "Line range $st-$en is invalid (file has ${lines.size} lines)")
        val repl = req(op, "text", i).split("\n")
        for (k in st..en) lines.removeAt(st - 1)
        lines.addAll(st - 1, repl)
        return lines.joinToString("\n")
    }

    /** Index of the matching close brace for the '{' at [open], skipping strings and comments. -1 if unbalanced. */
    fun matchBrace(s: String, open: Int): Int {
        var depth = 0; var i = open
        while (i < s.length) {
            val c = s[i]; val n = if (i + 1 < s.length) s[i + 1] else ' '
            when {
                c == '/' && n == '/' -> { while (i < s.length && s[i] != '\n') i++; continue }
                c == '/' && n == '*' -> { val e = s.indexOf("*/", i + 2); if (e < 0) return -1; i = e + 2; continue }
                c == '"' || c == '\'' || c == '`' -> {
                    val q = c; i++
                    while (i < s.length && s[i] != q) { if (s[i] == '\\') i++; i++ }
                }
                c == '{' -> depth++
                c == '}' -> { depth--; if (depth == 0) return i }
            }
            i++
        }
        return -1
    }

    private fun replaceFunction(s: String, op: JSONObject, i: Int): String {
        val name = req(op, "name", i); val text = req(op, "text", i)
        val n = Regex.escape(name)
        val patterns = listOf(
            Regex("(?m)^[ \\t]*(export\\s+)?(default\\s+)?(async\\s+)?function\\s*\\*?\\s*$n\\s*\\("),
            Regex("(?m)^[ \\t]*(export\\s+)?(const|let|var)\\s+$n\\s*=\\s*(async\\s*)?(function\\b|\\([^)]*\\)\\s*=>|[A-Za-z_$][\\w$]*\\s*=>)"),
            Regex("(?m)^[ \\t]*(static\\s+)?(async\\s+)?$n\\s*\\([^)]*\\)\\s*\\{"),
            Regex("(?m)^[ \\t]*[\\w$.]+\\.$n\\s*=\\s*(async\\s*)?(function\\b|\\([^)]*\\)\\s*=>)")
        )
        val starts = patterns.flatMap { it.findAll(s).toList() }.map { it.range.first }.distinct().sorted()
        if (starts.isEmpty()) throw PatchException(i, "Function '$name' not found")
        if (starts.size > 1) throw PatchException(i, "Function '$name' is defined ${starts.size} times; use replace_text with more context")
        val st = starts[0]
        // statement start (include leading indentation) .. end brace
        val bodyOpen = s.indexOf('{', st)
        val arrowNoBrace = Regex("=>\\s*[^\\s{]").find(s, st)?.let { it.range.first < (if (bodyOpen < 0) Int.MAX_VALUE else bodyOpen) } ?: false
        if (bodyOpen < 0 || arrowNoBrace) throw PatchException(i, "Function '$name' has no { } body that can be replaced safely")
        val end = matchBrace(s, bodyOpen)
        if (end < 0) throw PatchException(i, "Unbalanced braces while reading function '$name'")
        var e = end + 1
        if (e < s.length && s[e] == ';' && Regex("^[ \\t]*(export\\s+)?(const|let|var)|=>|=\\s*(async\\s*)?function").containsMatchIn(s.substring(st, bodyOpen + 1))) e++
        val indent = s.substring(st).takeWhile { it == ' ' || it == '\t' }
        val tl = text.trimEnd('\n').lines()
        val body = if (indent.isNotEmpty() && !tl[0].startsWith(" ") && !tl[0].startsWith("\t"))
            tl.joinToString("\n") { if (it.isBlank()) it else indent + it } else tl.joinToString("\n")
        return s.substring(0, st) + body + s.substring(e)
    }

    private fun setCss(s: String, op: JSONObject, i: Int): String {
        val sel = req(op, "selector", i).trim(); val prop = req(op, "property", i).trim(); val value = req(op, "value", i).trim()
        if (!Regex("[A-Za-z-]+").matches(prop)) throw PatchException(i, "Invalid CSS property '$prop'")
        val rule = Regex("(?m)(^|\\})\\s*${Regex.escape(sel)}\\s*\\{").find(s)
        if (rule == null) return s + (if (s.endsWith("\n") || s.isEmpty()) "" else "\n") + "$sel {\n  $prop: $value;\n}\n"
        val open = rule.range.last
        val close = matchBrace(s, open)
        if (close < 0) throw PatchException(i, "Unbalanced braces in CSS rule '$sel'")
        val body = s.substring(open + 1, close)
        val decl = Regex("(^|[;\\s])${Regex.escape(prop)}\\s*:[^;}]*;?")
        val m = decl.find(body)
        val newBody = if (m != null) {
            val lead = m.groupValues[1]
            body.substring(0, m.range.first) + lead + "$prop: $value;" + body.substring(m.range.last + 1)
        } else {
            val trimmed = body.trimEnd()
            val sep = if (trimmed.isEmpty() || trimmed.endsWith(";")) "" else ";"
            val indent = Regex("\\n([ \\t]+)\\S").find(body)?.groupValues?.get(1) ?: "  "
            trimmed + sep + "\n" + indent + "$prop: $value;\n"
        }
        return s.substring(0, open + 1) + newBody + s.substring(close)
    }
}

/** Minimal line diff (common prefix/suffix hunk) so LIA and the UI can show a before/after summary. */
object Diff {
    fun summarize(old: String?, new: String, maxLines: Int = 40): JSONObject {
        val a = (old ?: "").split("\n"); val b = new.split("\n")
        var p = 0
        while (p < a.size && p < b.size && a[p] == b[p]) p++
        var sa = a.size; var sb = b.size
        while (sa > p && sb > p && a[sa - 1] == b[sb - 1]) { sa--; sb-- }
        val removed = a.subList(p, sa); val added = b.subList(p, sb)
        val o = JSONObject()
        o.put("created", old == null)
        o.put("first_changed_line", p + 1)
        o.put("lines_removed", removed.size); o.put("lines_added", added.size)
        o.put("removed", JSONArray(removed.take(maxLines))); o.put("added", JSONArray(added.take(maxLines)))
        o.put("changed", old != new)
        return o
    }
}
