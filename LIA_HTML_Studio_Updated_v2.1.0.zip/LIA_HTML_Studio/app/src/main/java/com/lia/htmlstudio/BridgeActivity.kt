package com.lia.htmlstudio

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import org.json.JSONObject

/**
 * Intent bridge for LIA AI. Invisible activity.
 *
 *  action com.lia.htmlstudio.action.COMMAND   extras: command_json (String, full JSON incl. "token"), show_ui (Boolean, default true)
 *  legacy actions NEW_PROJECT / INSERT_CODE / REPLACE_ALL / RUN_PREVIEW  extras: token (required now), plus the old extras.
 *
 * The response JSON is returned as result extra "response" (use startActivityForResult) and is also available via
 * the ContentProvider command GET_LAST_RESPONSE. Every command needs the pairing token shown in IDE Settings.
 */
class BridgeActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LiaApi.init(this)
        val i = intent
        val token = i.getStringExtra("token") ?: runCatching { JSONObject(i.getStringExtra("command_json") ?: "{}").optString("token") }.getOrDefault("")
        val showUi = i.getBooleanExtra("show_ui", true)
        if (showUi) startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        waitForIde(if (showUi) 40 else 0) { build(i, token) }
    }

    private fun waitForIde(triesLeft: Int, run: () -> Unit) {
        if (LiaApi.controller != null || triesLeft <= 0) run() else ui.postDelayed({ waitForIde(triesLeft - 1, run) }, 100)
    }

    private fun build(i: Intent, token: String) {
        val o: JSONObject = when (i.action) {
            "com.lia.htmlstudio.action.COMMAND" -> runCatching { JSONObject(i.getStringExtra("command_json") ?: "") }.getOrElse { return finishWith(LiaApi.fail("?", "BAD_JSON", "command_json missing or invalid")) }
            "com.lia.htmlstudio.action.NEW_PROJECT" -> {
                val html = i.getStringExtra("html"); val fn = i.getStringExtra("filename") ?: "index.html"
                JSONObject().put("command", "CREATE_PROJECT").put("name", i.getStringExtra("name") ?: "LIA Project").put("auto_rename", true)
                    .also { if (html != null) it.put("files", JSONObject().put(fn, html)) }
            }
            "com.lia.htmlstudio.action.INSERT_CODE" -> JSONObject().put("command", "INSERT_CODE").put("text", i.getStringExtra("code").orEmpty())
            "com.lia.htmlstudio.action.REPLACE_ALL" -> {
                val snap = LiaApi.controller?.editorSnapshot() ?: return finishWith(LiaApi.fail("REPLACE_ALL", "NO_FILE_OPEN", "No file open in the IDE"))
                JSONObject().put("command", "UPDATE_FILE").put("project", snap.getString("project")).put("path", snap.getString("path")).put("content", i.getStringExtra("code").orEmpty())
            }
            "com.lia.htmlstudio.action.RUN_PREVIEW" -> JSONObject().put("command", "RUN_PROJECT")
            else -> return finishWith(LiaApi.fail("?", "UNKNOWN_ACTION", "Unsupported action"))
        }
        o.put("token", token)
        LiaApi.execute(o.toString()) { finishWith(it) }
    }

    private fun finishWith(resp: JSONObject) {
        setResult(RESULT_OK, Intent().putExtra("response", resp.toString()))
        finish()
    }
}
