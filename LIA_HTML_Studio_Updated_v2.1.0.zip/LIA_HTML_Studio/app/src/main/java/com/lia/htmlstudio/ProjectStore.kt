package com.lia.htmlstudio

import org.json.JSONObject
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class StoreException(val code: String, message: String) : Exception(message)

data class FileEntry(val path: String, val isDir: Boolean, val size: Long)
data class SearchHit(val path: String, val line: Int, val text: String)

/**
 * All project files live in app-private storage: <filesDir>/projects/<name>/...
 * Every path coming from the UI or from LIA is validated against the project root (no "..", no absolute paths).
 */
class ProjectStore(private val base: File) {
    private val projectsDir = File(base, "projects").apply { mkdirs() }
    private val historyDir = File(base, "history").apply { mkdirs() }
    private val backupDir = File(base, "backups").apply { mkdirs() }

    companion object {
        const val MAX_FILE_BYTES = 5L * 1024 * 1024
        const val MAX_ZIP_ENTRIES = 5000
        const val MAX_ZIP_TOTAL = 200L * 1024 * 1024
        val TEXT_EXT = setOf("html", "htm", "css", "js", "mjs", "json", "svg", "webmanifest", "map")
        val IMAGE_EXT = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp", "ico")

        fun ext(path: String) = path.substringAfterLast('.', "").lowercase()
        fun isText(path: String): Boolean { val e = ext(path); return e in TEXT_EXT || !path.substringAfterLast('/').contains('.') }
        fun isImage(path: String) = ext(path) in IMAGE_EXT
    }

    // ---------- names & paths ----------
    fun validateProjectName(name: String): String {
        val n = name.trim()
        if (n.isEmpty() || n.length > 64 || n.startsWith(".") || !Regex("[A-Za-z0-9 _.\\-]+").matches(n))
            throw StoreException("INVALID_NAME", "Project name must be 1-64 chars of letters, digits, space, _ . -")
        return n
    }

    fun projectDir(project: String): File = File(projectsDir, validateProjectName(project))
    fun exists(project: String) = runCatching { projectDir(project).isDirectory }.getOrDefault(false)

    fun resolve(project: String, rel: String): File {
        val root = projectDir(project).canonicalFile
        val clean = rel.replace('\\', '/').trim('/')
        if (clean.isEmpty()) return root
        if (clean.split('/').any { it == ".." || it.isEmpty() || it == "." })
            throw StoreException("INVALID_PATH", "Illegal path: $rel")
        val f = File(root, clean).canonicalFile
        if (f.path != root.path && !f.path.startsWith(root.path + File.separator))
            throw StoreException("PATH_ESCAPE", "Path escapes project: $rel")
        return f
    }

    fun relPath(project: String, f: File): String =
        f.canonicalFile.path.removePrefix(projectDir(project).canonicalFile.path).trimStart(File.separatorChar).replace('\\', '/')

    // ---------- projects ----------
    fun listProjects(): List<String> =
        (projectsDir.listFiles() ?: emptyArray()).filter { it.isDirectory }.sortedByDescending { it.lastModified() }.map { it.name }

    fun createProject(name: String, template: String = "html", extraFiles: Map<String, String> = emptyMap()): String {
        val n = validateProjectName(name)
        val dir = File(projectsDir, n)
        if (dir.exists()) throw StoreException("PROJECT_EXISTS", "Project '$n' already exists")
        dir.mkdirs()
        val files = if (extraFiles.isNotEmpty()) extraFiles else Templates.files(template)
        for ((p, c) in files) write(n, p, c)
        return n
    }

    fun deleteProject(project: String) { projectDir(project).deleteRecursively() }

    fun uniqueName(preferred: String): String {
        val b = preferred.replace(Regex("[^A-Za-z0-9 _.\\-]"), "_").trim().trimStart('.').take(56).ifEmpty { "Project" }
        var n = b; var i = 2
        while (File(projectsDir, n).exists()) { n = "$b $i"; i++ }
        return n
    }

    // ---------- files ----------
    fun tree(project: String, limit: Int = 3000): List<FileEntry> {
        val root = projectDir(project)
        val out = ArrayList<FileEntry>()
        fun walk(d: File) {
            val kids = (d.listFiles() ?: return).sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
            for (k in kids) {
                if (out.size >= limit) return
                out.add(FileEntry(relPath(project, k), k.isDirectory, if (k.isFile) k.length() else 0))
                if (k.isDirectory) walk(k)
            }
        }
        walk(root)
        return out
    }

    fun read(project: String, rel: String): String {
        val f = resolve(project, rel)
        if (!f.isFile) throw StoreException("NOT_FOUND", "File not found: $rel")
        if (f.length() > MAX_FILE_BYTES) throw StoreException("TOO_LARGE", "File larger than ${MAX_FILE_BYTES / 1024 / 1024} MB: $rel")
        return f.readText(Charsets.UTF_8)
    }

    fun fileExists(project: String, rel: String) = runCatching { resolve(project, rel).isFile }.getOrDefault(false)

    /** Atomic write: temp file + rename, so a crash never leaves a half-written file. */
    fun write(project: String, rel: String, text: String) {
        val f = resolve(project, rel)
        if (f.isDirectory) throw StoreException("IS_DIRECTORY", "$rel is a folder")
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, f.name + ".lia-tmp")
        tmp.writeText(text, Charsets.UTF_8)
        if (!tmp.renameTo(f)) { f.delete(); if (!tmp.renameTo(f)) { tmp.delete(); throw StoreException("WRITE_FAILED", "Could not write $rel") } }
    }

    fun writeBytes(project: String, rel: String, input: InputStream) {
        val f = resolve(project, rel); f.parentFile?.mkdirs()
        FileOutputStream(f).use { o -> input.copyTo(o) }
    }

    fun mkdir(project: String, rel: String) { val d = resolve(project, rel); if (!d.exists() && !d.mkdirs()) throw StoreException("MKDIR_FAILED", "Cannot create folder $rel") }

    fun delete(project: String, rel: String) {
        val f = resolve(project, rel)
        if (f == projectDir(project).canonicalFile) throw StoreException("INVALID_PATH", "Cannot delete project root this way")
        if (!f.exists()) throw StoreException("NOT_FOUND", "Not found: $rel")
        if (!f.deleteRecursively()) throw StoreException("DELETE_FAILED", "Could not delete $rel")
    }

    fun rename(project: String, rel: String, newRel: String) = move(project, rel, newRel)

    fun move(project: String, rel: String, destRel: String) {
        val src = resolve(project, rel); val dst = resolve(project, destRel)
        if (!src.exists()) throw StoreException("NOT_FOUND", "Not found: $rel")
        if (dst.exists()) throw StoreException("EXISTS", "Destination exists: $destRel")
        if (dst.path.startsWith(src.path + File.separator)) throw StoreException("INVALID_PATH", "Cannot move a folder into itself")
        dst.parentFile?.mkdirs()
        if (!src.renameTo(dst)) { src.copyRecursively(dst); src.deleteRecursively() }
    }

    fun copy(project: String, rel: String, destRel: String) {
        val src = resolve(project, rel); val dst = resolve(project, destRel)
        if (!src.exists()) throw StoreException("NOT_FOUND", "Not found: $rel")
        if (dst.exists()) throw StoreException("EXISTS", "Destination exists: $destRel")
        if (dst.path.startsWith(src.path + File.separator)) throw StoreException("INVALID_PATH", "Cannot copy a folder into itself")
        dst.parentFile?.mkdirs()
        src.copyRecursively(dst)
    }

    fun search(project: String, query: String, caseSensitive: Boolean, maxHits: Int = 300): List<SearchHit> {
        if (query.isEmpty()) return emptyList()
        val hits = ArrayList<SearchHit>()
        for (e in tree(project)) {
            if (e.isDir || !isText(e.path) || e.size > 1_500_000) continue
            val lines = runCatching { read(project, e.path).lines() }.getOrNull() ?: continue
            for ((i, l) in lines.withIndex()) {
                if (l.contains(query, ignoreCase = !caseSensitive)) {
                    hits.add(SearchHit(e.path, i + 1, l.trim().take(160)))
                    if (hits.size >= maxHits) return hits
                }
            }
        }
        return hits
    }

    // ---------- ZIP ----------
    /** Zip-slip safe, zip-bomb limited import. Strips a single wrapping top-level folder. Returns project name. */
    fun importZip(input: InputStream, preferredName: String): String {
        val name = uniqueName(preferredName)
        val tmp = File(base, "import_" + System.nanoTime()).apply { mkdirs() }
        try {
            var entries = 0; var total = 0L
            ZipInputStream(BufferedInputStream(input)).use { zin ->
                var e: ZipEntry? = zin.nextEntry
                while (e != null) {
                    if (++entries > MAX_ZIP_ENTRIES) throw StoreException("ZIP_TOO_MANY", "ZIP has too many entries")
                    val n = e.name.replace('\\', '/').trim('/')
                    val bad = n.isEmpty() || n.split('/').any { it == ".." } || n.startsWith("__MACOSX") || n.contains("/.git/") || n.startsWith(".git/")
                    if (!bad) {
                        val out = File(tmp, n).canonicalFile
                        if (!out.path.startsWith(tmp.canonicalPath + File.separator)) throw StoreException("PATH_ESCAPE", "Unsafe ZIP entry: ${e.name}")
                        if (e.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { fo ->
                                val buf = ByteArray(16384); var r: Int
                                while (zin.read(buf).also { r = it } > 0) {
                                    total += r
                                    if (total > MAX_ZIP_TOTAL) throw StoreException("ZIP_TOO_BIG", "ZIP expands beyond ${MAX_ZIP_TOTAL / 1024 / 1024} MB")
                                    fo.write(buf, 0, r)
                                }
                            }
                        }
                    }
                    zin.closeEntry(); e = zin.nextEntry
                }
            }
            val kids = tmp.listFiles() ?: emptyArray()
            val src = if (kids.size == 1 && kids[0].isDirectory) kids[0] else tmp
            if (src.listFiles().isNullOrEmpty()) throw StoreException("ZIP_EMPTY", "ZIP contained no usable files")
            val dest = File(projectsDir, name)
            if (!src.renameTo(dest)) { src.copyRecursively(dest); }
            return name
        } finally { tmp.deleteRecursively() }
    }

    fun exportZip(project: String, out: OutputStream) {
        val root = projectDir(project)
        ZipOutputStream(BufferedOutputStream(out)).use { z ->
            root.walkTopDown().filter { it.isFile && !it.name.endsWith(".lia-tmp") }.forEach { f ->
                z.putNextEntry(ZipEntry(f.relativeTo(root).path.replace('\\', '/')))
                FileInputStream(f).use { it.copyTo(z) }
                z.closeEntry()
            }
        }
    }

    // ---------- backups ----------
    fun backup(project: String): File {
        val f = File(backupDir, "${validateProjectName(project)}__${System.currentTimeMillis()}.zip")
        FileOutputStream(f).use { exportZip(project, it) }
        return f
    }
    fun listBackups(): List<File> = (backupDir.listFiles() ?: emptyArray()).filter { it.name.endsWith(".zip") }.sortedByDescending { it.lastModified() }
    fun restoreBackup(f: File): String {
        val pn = f.name.substringBefore("__")
        return FileInputStream(f).use { importZip(it, "$pn restored") }
    }

    // ---------- change history (undo of AI edits) ----------
    private fun hdir(project: String) = File(historyDir, validateProjectName(project)).apply { mkdirs() }

    fun recordChange(project: String, rel: String, before: String?, cause: String) {
        val d = hdir(project)
        val seq = (d.listFiles()?.mapNotNull { it.name.removeSuffix(".json").toLongOrNull() }?.maxOrNull() ?: 0L) + 1
        val o = JSONObject().put("file", rel).put("existed", before != null).put("content", before ?: "")
            .put("cause", cause).put("time", System.currentTimeMillis())
        File(d, "$seq.json").writeText(o.toString())
        // keep last 200 records
        d.listFiles()?.sortedBy { it.name.removeSuffix(".json").toLongOrNull() ?: 0L }?.let { l -> if (l.size > 200) l.take(l.size - 200).forEach { it.delete() } }
    }

    fun listChanges(project: String): List<JSONObject> =
        (hdir(project).listFiles() ?: emptyArray()).sortedByDescending { it.name.removeSuffix(".json").toLongOrNull() ?: 0L }
            .mapNotNull { runCatching { JSONObject(it.readText()).also { o -> o.remove("content"); o.put("id", it.name.removeSuffix(".json")) } }.getOrNull() }

    /** Restores the latest recorded change. Returns the file path that was restored, or null if none. */
    fun undoLastChange(project: String): String? {
        val f = (hdir(project).listFiles() ?: return null).maxByOrNull { it.name.removeSuffix(".json").toLongOrNull() ?: 0L } ?: return null
        val o = JSONObject(f.readText())
        val rel = o.getString("file")
        if (o.getBoolean("existed")) write(project, rel, o.getString("content")) else resolve(project, rel).delete()
        f.delete()
        return rel
    }
}
