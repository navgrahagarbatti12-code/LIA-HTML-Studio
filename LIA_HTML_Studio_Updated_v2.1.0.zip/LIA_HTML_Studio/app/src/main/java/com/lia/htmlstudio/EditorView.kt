package com.lia.htmlstudio

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.*
import android.text.style.BackgroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.widget.EditText

class MatchSpan(c: Int) : BackgroundColorSpan(c)
class ErrorSpan(c: Int) : BackgroundColorSpan(c)

/**
 * Code editor on top of EditText: line-number gutter, syntax highlighting, bracket matching, auto-indent,
 * auto-close brackets, snapshot undo/redo, find/replace, error-line marking.
 * HTML tag completion, bracket matching, auto-indent, undo/redo and find/replace are supported.
 * Code folding and multi-cursor are not implemented in this EditText-based editor.
 */
class EditorView(ctx: Context) : EditText(ctx) {
    var palette: Palette = Themes.DARK
    var lang: String = "text"
    var onUserChange: (() -> Unit)? = null
    var autoClose = true
    private var ready = false
    private var loading = false
    private val ui = Handler(Looper.getMainLooper())
    private val gutterPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaint = Paint()
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()
    private var gutterW = 0f
    private val hl = Runnable { rehighlight() }
    private val snap = Runnable { commitSnapshot() }

    init {
        gravity = Gravity.TOP or Gravity.START
        setHorizontallyScrolling(true)
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        isVerticalScrollBarEnabled = true
        isHorizontalScrollBarEnabled = true
        setBackgroundColor(0)
        isSaveEnabled = false
        filters = arrayOf(InputFilter { source, start, end, dest, dstart, dend -> smartFilter(source, start, end, dest, dstart, dend) })
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (loading) return
                ui.removeCallbacks(hl); ui.postDelayed(hl, 250)
                ui.removeCallbacks(snap); ui.postDelayed(snap, 700)
                updateGutter()
                onUserChange?.invoke()
            }
        })
        ready = true
    }

    fun applyStyle(p: Palette, sizeSp: Float, tf: Typeface) {
        palette = p
        typeface = tf; setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setTextColor(p.text); setHintTextColor(p.muted); highlightColor = p.match
        setBackgroundColor(p.bg)
        gutterPaint.typeface = tf; gutterPaint.textSize = textSize * 0.85f; gutterPaint.color = p.gutterText
        bgPaint.color = p.gutter
        updateGutter(); rehighlight()
    }

    private fun updateGutter() {
        val digits = maxOf(2, lineCount.toString().length)
        val w = gutterPaint.measureText("8".repeat(digits)) + 24f
        if (w != gutterW) { gutterW = w; setPadding((w + 12f).toInt(), 12, 24, 12) }
    }

    // ---------- content ----------
    fun load(text: String, language: String) {
        loading = true
        lang = language
        setText(text)
        loading = false
        undoStack.clear(); redoStack.clear(); undoStack.addLast(text)
        updateGutter(); rehighlight()
    }

    fun rehighlight() { val e = text ?: return; Highlighter.apply(e, lang, palette); updateBracketMatch() }

    // ---------- undo / redo ----------
    private fun commitSnapshot() {
        val t = text.toString()
        if (undoStack.lastOrNull() == t) return
        undoStack.addLast(t); redoStack.clear()
        if (undoStack.size > 80) undoStack.removeFirst()
    }
    fun canUndo(): Boolean { commitSnapshot(); return undoStack.size > 1 }
    fun undo() { ui.removeCallbacks(snap); if (!canUndo()) return; redoStack.addLast(undoStack.removeLast()); restore(undoStack.last()) }
    fun redo() { if (redoStack.isEmpty()) return; val t = redoStack.removeLast(); undoStack.addLast(t); restore(t) }
    private fun restore(t: String) {
        val sel = selectionStart.coerceAtLeast(0)
        loading = true; setText(t); loading = false
        setSelection(minOf(sel, t.length)); updateGutter(); rehighlight(); onUserChange?.invoke()
    }

    // ---------- smart typing ----------
    private fun smartFilter(source: CharSequence, start: Int, end: Int, dest: Spanned, dstart: Int, dend: Int): CharSequence? {
        if (!ready || loading || end - start != 1 || dstart != dend) return null
        val c = source[start]
        if (c == '\n') {
            val ls = dest.lastIndexOf('\n', dstart - 1).let { if (it < 0) 0 else it + 1 }
            val line = dest.subSequence(ls, dstart)
            val indent = line.takeWhile { it == ' ' || it == '\t' }
            val trimmed = line.trimEnd()
            val extra = if (trimmed.isNotEmpty() && trimmed.last() in "{[(") "  " else ""
            val next = if (dend < dest.length) dest[dend] else ' '
            if (extra.isNotEmpty() && trimmed.last() in "{[(" && next == closer(trimmed.last())) {
                // pressing Enter between {} -> put the closer on its own line
                val ins = "\n$indent$extra\n$indent"
                ui.post { setSelection((dstart + 1 + indent.length + extra.length).coerceAtMost(length())) }
                return ins
            }
            return "\n$indent$extra"
        }
        if (!autoClose || lang == "text") return null
        val next = if (dend < dest.length) dest[dend] else '\u0000'
        // Complete ordinary HTML opening tags when the user types the closing angle bracket.
        if (c == '>' && lang == "html") {
            val before = dest.subSequence(0, dstart).toString()
            val tag = Regex("<([A-Za-z][A-Za-z0-9:-]*)(?:\\s+[^<>]*)?$").find(before)
            if (tag != null && !before.trimEnd().endsWith("/") && !before.startsWith("</")) {
                val name = tag.groupValues[1]
                val voidTags = setOf("area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr")
                if (name.lowercase() !in voidTags) {
                    val closing = "</$name>"
                    if (!dest.subSequence(dend, dest.length).toString().startsWith(closing)) {
                        ui.post { setSelection((dstart + 1).coerceAtMost(length())) }
                        return ">$closing"
                    }
                }
            }
        }
        if (c == ')' || c == ']' || c == '}' || c == '"' || c == '\'') {
            if (next == c) { ui.post { setSelection(dstart + 1) }; return "" }   // type over the closer
        }
        val pair = when (c) { '(' -> ")"; '[' -> "]"; '{' -> "}"; else -> null }
        if (pair != null) { ui.post { setSelection(dstart + 1) }; return "$c$pair" }
        if ((c == '"' || c == '\'') && (next == '\u0000' || next.isWhitespace() || next in ")]}>,;")) {
            val prev = if (dstart > 0) dest[dstart - 1] else ' '
            if (!prev.isLetterOrDigit()) { ui.post { setSelection(dstart + 1) }; return "$c$c" }
        }
        return null
    }
    private fun closer(o: Char) = when (o) { '{' -> '}'; '[' -> ']'; else -> ')' }
    private fun CharSequence.lastIndexOf(ch: Char, from: Int): Int { var i = minOf(from, length - 1); while (i >= 0) { if (this[i] == ch) return i; i-- }; return -1 }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (event.isCtrlPressed) when (keyCode) {
            KeyEvent.KEYCODE_Z -> { if (event.isShiftPressed) redo() else undo(); return true }
            KeyEvent.KEYCODE_Y -> { redo(); return true }
        }
        if (keyCode == KeyEvent.KEYCODE_TAB && !event.isShiftPressed) { text.replace(selectionStart, selectionEnd, "  "); return true }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- bracket matching ----------
    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        if (ready && !loading) updateBracketMatch()
    }

    private fun updateBracketMatch() {
        val e = text ?: return
        for (s in e.getSpans(0, e.length, MatchSpan::class.java)) e.removeSpan(s)
        if (selectionStart != selectionEnd || selectionStart < 0) return
        val pos = selectionStart
        for (p in intArrayOf(pos - 1, pos)) {
            if (p < 0 || p >= e.length) continue
            val c = e[p]
            val open = c in "([{"; val close = c in ")]}"
            if (!open && !close) continue
            val other = if (open) c else when (c) { ')' -> '('; ']' -> '['; else -> '{' }
            val oc = when (other) { '(' -> ')'; '[' -> ']'; else -> '}' }
            var depth = 0; var i = p; val step = if (open) 1 else -1; var steps = 0
            while (i in 0 until e.length && steps < 20000) {
                val d = e[i]
                if (d == other) depth += if (open) 1 else -1 else if (d == oc) depth += if (open) -1 else 1
                if (depth == 0) { e.setSpan(MatchSpan(palette.match), p, p + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); e.setSpan(MatchSpan(palette.match), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); return }
                i += step; steps++
            }
            return
        }
    }

    // ---------- errors ----------
    fun markErrors(lines: Set<Int>) {
        val e = text ?: return
        for (s in e.getSpans(0, e.length, ErrorSpan::class.java)) e.removeSpan(s)
        val l = layout ?: return
        for (ln in lines) {
            if (ln < 1 || ln > l.lineCount) continue
            val a = l.getLineStart(ln - 1); val b = l.getLineEnd(ln - 1)
            if (b > a) e.setSpan(ErrorSpan(palette.error), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    fun gotoLine(line: Int) {
        val l = layout ?: return
        val i = (line - 1).coerceIn(0, l.lineCount - 1)
        setSelection(l.getLineStart(i)); requestFocus()
        post { scrollTo(0, (l.getLineTop(i) - height / 3).coerceAtLeast(0)) }
    }

    fun currentLine(): Int = layout?.getLineForOffset(selectionStart.coerceAtLeast(0))?.plus(1) ?: 1

    // ---------- find / replace ----------
    fun find(q: String, forward: Boolean, cs: Boolean): Boolean {
        if (q.isEmpty()) return false
        val t = text.toString()
        var idx = if (forward) t.indexOf(q, selectionEnd.coerceAtLeast(0), !cs) else t.lastIndexOf(q, (selectionStart - 1).coerceAtLeast(0), !cs)
        if (idx < 0) idx = if (forward) t.indexOf(q, 0, !cs) else t.lastIndexOf(q, t.length, !cs)
        if (idx < 0) return false
        setSelection(idx, idx + q.length); requestFocus()
        layout?.let { l -> val top = l.getLineTop(l.getLineForOffset(idx)); if (top < scrollY || top > scrollY + height - 100) scrollTo(scrollX, (top - height / 3).coerceAtLeast(0)) }
        return true
    }
    fun replaceCurrent(q: String, r: String, cs: Boolean): Boolean {
        val sel = text.substring(selectionStart.coerceAtLeast(0), selectionEnd.coerceAtLeast(0))
        if (q.isNotEmpty() && sel.equals(q, ignoreCase = !cs)) { text.replace(selectionStart, selectionEnd, r) }
        return find(q, true, cs)
    }
    fun replaceAll(q: String, r: String, cs: Boolean): Int {
        if (q.isEmpty()) return 0
        val t = text.toString()
        val n = Regex(Regex.escape(q), if (cs) emptySet() else setOf(RegexOption.IGNORE_CASE)).findAll(t).count()
        if (n > 0) { val nt = t.replace(q, r, ignoreCase = !cs); text.replace(0, text.length, nt) }
        return n
    }

    // ---------- drawing ----------
    override fun onDraw(canvas: Canvas) {
        val l = layout
        if (l != null) { // current-line highlight
            val ln = l.getLineForOffset(selectionStart.coerceAtLeast(0))
            bgPaint.color = palette.selectionLine
            canvas.drawRect(0f + scrollX, l.getLineTop(ln).toFloat() + paddingTop, (scrollX + width).toFloat(), l.getLineBottom(ln).toFloat() + paddingTop, bgPaint)
        }
        super.onDraw(canvas)
        if (l == null) return
        bgPaint.color = palette.gutter
        canvas.drawRect(scrollX.toFloat(), scrollY.toFloat(), scrollX + gutterW, (scrollY + height).toFloat(), bgPaint)
        val first = l.getLineForVertical(scrollY); val last = l.getLineForVertical(scrollY + height)
        gutterPaint.textAlign = Paint.Align.RIGHT
        val cur = l.getLineForOffset(selectionStart.coerceAtLeast(0))
        for (i in first..last) {
            gutterPaint.color = if (i == cur) palette.text else palette.gutterText
            canvas.drawText((i + 1).toString(), scrollX + gutterW - 10f, (l.getLineBaseline(i) + paddingTop).toFloat(), gutterPaint)
        }
    }
}
