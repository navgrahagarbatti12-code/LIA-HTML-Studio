package com.lia.htmlstudio

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

data class ConsoleEntry(val level: String, val message: String, val source: String, val line: Int, val time: Long) {
    fun toJson(): JSONObject {
        val (en, hi) = Explain.explain(message)
        val o = JSONObject().put("level", level).put("message", message).put("source", source).put("line", line).put("time", time)
        if (level == "ERROR") o.put("explain_en", en).put("explain_hi", hi)
        return o
    }
}

/** Implemented by MainActivity while it is alive. All methods are called on the main thread. */
interface IdeController {
    val project: String?
    fun openProject(name: String)
    fun editorSnapshot(): JSONObject?                 // {project,path,text,sel_start,sel_end,dirty}
    fun insertAtCursor(text: String): Boolean
    fun replaceSelection(text: String): Boolean
    fun flush(project: String, path: String?)         // write dirty editor text to disk
    fun reload(project: String, path: String?)        // re-read a file/tree after an external change
    fun runProject(entry: String?, mode: String?, done: (JSONObject) -> Unit)
    fun stopPreview()
    fun console(): List<ConsoleEntry>
    fun status(): JSONObject
    fun notifyApprovals()
}

class Approval(val id: String, val command: String, val request: JSONObject, val description: String) {
    @Volatile var status = "pending"       // pending | approved | denied | expired
    @Volatile var result: JSONObject? = null
    val created = System.currentTimeMillis()
}

/**
 * The single entry point for every external command (ContentProvider, intents). Commands are plain JSON:
 *   {"token":"...","command":"APPLY_PATCH","project":"Game","file":"js/game.js","ops":[...]}
 * Responses: {"ok":true,"command":"...","result":{...}} or {"ok":false,"command":"...","error":{"code":"...","message":"..."}}
 */
object LiaApi {
    const val VERSION = 2
    val COMMANDS = listOf("GET_CAPABILITIES", "CREATE_PROJECT", "OPEN_PROJECT", "LIST_PROJECTS", "LIST_FILES", "READ_FILE", "GET_CURRENT_FILE",
        "INSERT_CODE", "REPLACE_SELECTION", "APPLY_PATCH", "CREATE_FILE", "UPDATE_FILE", "DELETE_FILE", "SAVE_FILE", "RUN_PROJECT",
        "STOP_PREVIEW", "GET_CONSOLE", "GET_CONSOLE_ERRORS", "GET_PROJECT_STATUS", "VALIDATE_FILE", "UNDO_LAST_AI_CHANGE", "LIST_CHANGES",
        "GET_APPROVAL_STATUS", "GET_LAST_RESPONSE")

    private lateinit var appCtx: Context
    lateinit var store: ProjectStore
    lateinit var prefs: SharedPreferences
    @Volatile var controller: IdeController? = null
    private val main = Handler(Looper.getMainLooper())
    private val approvals = LinkedHashMap<String, Approval>()
    private val activity = ArrayList<String>()
    @Volatile var lastResponse: JSONObject? = null
    @Volatile var lastRun: JSONObject? = null

    @Synchronized fun init(ctx: Context) {
        if (this::store.isInitialized) return
        appCtx = ctx.applicationContext
        store = ProjectStore(appCtx.filesDir)
        prefs = appCtx.getSharedPreferences("lia_ide", Context.MODE_PRIVATE)
    }

    // ---------- token ----------
    @Synchronized fun token(): String {
        var t = prefs.getString("api_token", null)
        if (t == null) { t = newToken(); prefs.edit().putString("api_token", t).apply() }
        return t
    }
    @Synchronized fun regenerateToken(): String { val t = newToken(); prefs.edit().putString("api_token", t).apply(); return t }
    private fun newToken(): String { val b = ByteArray(24); SecureRandom().nextBytes(b); return b.joinToString("") { "%02x".format(it) } }
    private fun tokenOk(given: String) = MessageDigest.isEqual(given.toByteArray(), token().toByteArray())

    // ---------- activity log ----------
    @Synchronized private fun log(s: String) { activity.add(java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date()) + "  " + s); if (activity.size > 150) activity.removeAt(0) }
    @Synchronized fun activityLog(): List<String> = activity.toList()

    // ---------- approvals ----------
    @Synchronized fun pendingApprovals(): List<Approval> {
        val now = System.currentTimeMillis()
        approvals.values.filter { it.status == "pending" && now - it.created > 15 * 60_000 }.forEach { it.status = "expired" }
        return approvals.values.filter { it.status == "pending" }
    }

    fun resolveApproval(id: String, approve: Boolean) {
        val a = synchronized(this) { approvals[id] } ?: return
        if (a.status != "pending") return
        if (!approve) { a.status = "denied"; a.result = fail(a.command, "DENIED", "The user denied this operation"); log("DENIED ${a.command}"); return }
        a.status = "approved"
        run(a.command, a.request, approved = true) { a.result = it }
    }

    // ---------- entry points ----------
    fun executeBlocking(json: String, timeoutMs: Long = 20_000): JSONObject {
        var out: JSONObject? = null
        val latch = CountDownLatch(1)
        execute(json) { out = it; latch.countDown() }
        if (!latch.await(timeoutMs, TimeUnit.MILLISECONDS)) return fail("?", "TIMEOUT", "The IDE did not finish in time; check GET_LAST_RESPONSE")
        return out!!
    }

    fun execute(json: String, done: (JSONObject) -> Unit) {
        val once = AtomicBoolean(false)
        val finish: (JSONObject) -> Unit = { r -> if (once.compareAndSet(false, true)) { lastResponse = r; done(r) } }
        val req = try { JSONObject(json) } catch (e: Exception) { finish(fail("?", "BAD_JSON", "Command is not valid JSON")); return }
        val cmd = req.optString("command").uppercase()
        if (!tokenOk(req.optString("token"))) { log("REJECTED $cmd (bad token)"); finish(fail(cmd, "UNAUTHORIZED", "Missing or wrong pairing token. Copy it from IDE → Settings → LIA integration.")); return }
        main.post { run(cmd, req, false, finish) }
    }

    // ---------- helpers ----------
    private fun ok(cmd: String, result: JSONObject = JSONObject()) = JSONObject().put("ok", true).put("command", cmd).put("result", result)
    fun fail(cmd: String, code: String, msg: String) =
        JSONObject().put("ok", false).put("command", cmd).put("error", JSONObject().put("code", code).put("message", msg))

    private fun project(req: JSONObject): String {
        val p = req.optString("project").ifEmpty { controller?.project ?: prefs.getString("last_project", null) ?: "" }
        if (p.isEmpty()) throw StoreException("NO_PROJECT", "No project specified and none is open")
        if (!store.exists(p)) throw StoreException("PROJECT_NOT_FOUND", "Project '$p' does not exist")
        return p
    }

    private fun needApproval(cmd: String, req: JSONObject, desc: String, done: (JSONObject) -> Unit) {
        val a = Approval(java.util.UUID.randomUUID().toString().take(12), cmd, req, desc)
        synchronized(this) { approvals[a.id] = a }
        log("APPROVAL REQUESTED: $desc")
        controller?.notifyApprovals()
        done(JSONObject().put("ok", false).put("command", cmd).put("status", "pending_approval").put("approval_id", a.id)
            .put("message", "The user must approve this in the IDE ($desc). Poll GET_APPROVAL_STATUS with approval_id.")
            .put("ui_attached", controller != null))
    }

    fun problemsJson(project: String, onlyPath: String? = null): JSONArray {
        val arr = JSONArray()
        val files = if (onlyPath != null) listOf(onlyPath) else store.tree(project).filter { !it.isDir && ProjectStore.isText(it.path) && it.size < 1_000_000 }.map { it.path }
        for (f in files) {
            val text = runCatching { store.read(project, f) }.getOrNull() ?: continue
            for (p in Validator.validate(f, text)) arr.put(p.toJson().put("file", f))
        }
        return arr
    }

    private fun trackedWrite(project: String, rel: String, text: String, cause: String): JSONObject {
        controller?.flush(project, rel)
        val before = if (store.fileExists(project, rel)) store.read(project, rel) else null
        store.recordChange(project, rel, before, cause)
        store.write(project, rel, text)
        controller?.reload(project, rel)
        val d = Diff.summarize(before, text)
        return JSONObject().put("file", rel).put("diff", d).put("problems", problemsJson(project, rel))
            .put("note", "Static checks only (brackets/tags/JSON). Use RUN_PROJECT then GET_CONSOLE_ERRORS to verify runtime behaviour.")
    }

    // ---------- dispatcher (main thread) ----------
    private fun run(cmd: String, req: JSONObject, approved: Boolean, done: (JSONObject) -> Unit) {
        try {
            val r: JSONObject? = handle(cmd, req, approved, done)
            if (r != null) { log("$cmd ${if (r.optBoolean("ok")) "ok" else "FAILED " + r.optJSONObject("error")?.optString("code")}"); done(r) }
        } catch (e: StoreException) { log("$cmd FAILED ${e.code}"); done(fail(cmd, e.code, e.message ?: "")) }
        catch (e: PatchException) { log("$cmd PATCH FAILED op#${e.opIndex}"); done(fail(cmd, "PATCH_FAILED", "op #${e.opIndex}: ${e.message}").also { it.getJSONObject("error").put("op_index", e.opIndex) }) }
        catch (e: org.json.JSONException) { done(fail(cmd, "BAD_REQUEST", e.message ?: "bad request")) }
        catch (e: Throwable) { log("$cmd CRASH ${e.javaClass.simpleName}"); done(fail(cmd, "INTERNAL", "${e.javaClass.simpleName}: ${e.message}")) }
    }

    /** Returns a response, or null when the command completes asynchronously through [done] itself. */
    private fun handle(cmd: String, req: JSONObject, approved: Boolean, done: (JSONObject) -> Unit): JSONObject? {
        when (cmd) {
            "GET_CAPABILITIES" -> return ok(cmd, JSONObject().put("api_version", VERSION).put("commands", JSONArray(COMMANDS))
                .put("ui_attached", controller != null)
                .put("capabilities", JSONObject()
                    .put("edit_languages", JSONArray(listOf("html", "css", "js", "json")))
                    .put("execute_html_css_js", true).put("execute_python", false).put("git", false)
                    .put("patch_ops", JSONArray(listOf("replace_text", "insert_after", "insert_before", "replace_function", "replace_lines", "set_css_property", "append", "prepend"))))
                .put("templates", JSONArray(Templates.names)))
            "LIST_PROJECTS" -> return ok(cmd, JSONObject().put("projects", JSONArray(store.listProjects())).put("current", controller?.project ?: JSONObject.NULL))
            "GET_LAST_RESPONSE" -> return lastResponse ?: fail(cmd, "NONE", "No previous response")
            "GET_APPROVAL_STATUS" -> {
                val a = synchronized(this) { approvals[req.optString("approval_id")] } ?: return fail(cmd, "NOT_FOUND", "Unknown approval_id")
                pendingApprovals()
                return ok(cmd, JSONObject().put("status", a.status).put("result", a.result ?: JSONObject.NULL))
            }
            "CREATE_PROJECT" -> {
                val name0 = req.optString("name").ifEmpty { "LIA Project" }
                val template = req.optString("template", "html")
                val files = LinkedHashMap<String, String>()
                req.optJSONObject("files")?.let { fo -> fo.keys().forEach { k -> files[k] = fo.getString(k) } }
                if (store.exists(name0)) {
                    if (req.optBoolean("overwrite")) {
                        if (!approved) { needApproval(cmd, req, "Replace entire project '$name0'", done); return null }
                        store.backup(name0); store.deleteProject(name0)
                    } else if (!req.optBoolean("auto_rename")) return fail(cmd, "PROJECT_EXISTS", "Project '$name0' exists. Use another name, auto_rename:true, or overwrite:true (needs user approval).")
                }
                val name = if (store.exists(name0)) store.uniqueName(name0) else name0
                store.createProject(name, template, files)
                prefs.edit().putBoolean("trusted_$name", true).putString("last_project", name).apply()
                controller?.openProject(name)
                return ok(cmd, JSONObject().put("project", name).put("files", JSONArray(store.tree(name).filter { !it.isDir }.map { it.path })))
            }
            "OPEN_PROJECT" -> {
                val p = project(req); prefs.edit().putString("last_project", p).apply(); controller?.openProject(p)
                return ok(cmd, JSONObject().put("project", p).put("ui_attached", controller != null))
            }
            "LIST_FILES" -> {
                val p = project(req)
                val arr = JSONArray(); store.tree(p).forEach { arr.put(JSONObject().put("path", it.path).put("dir", it.isDir).put("size", it.size)) }
                return ok(cmd, JSONObject().put("project", p).put("files", arr))
            }
            "READ_FILE" -> {
                val p = project(req); val path = req.getString("path")
                if (!ProjectStore.isText(path)) return fail(cmd, "NOT_TEXT", "Not a text file")
                controller?.flush(p, path)
                val text = store.read(p, path)
                val lines = text.split("\n")
                val s = req.optInt("start_line", 0); val e = req.optInt("end_line", 0)
                if (s == 0 && text.length > 1_000_000) return fail(cmd, "TOO_LARGE", "File is ${text.length} chars; request start_line/end_line")
                val body = if (s > 0) lines.subList((s - 1).coerceIn(0, lines.size), (if (e > 0) e else lines.size).coerceIn(0, lines.size)).joinToString("\n") else text
                return ok(cmd, JSONObject().put("project", p).put("path", path).put("content", body).put("total_lines", lines.size))
            }
            "GET_CURRENT_FILE" -> {
                val c = controller ?: return fail(cmd, "NO_UI", "The IDE screen is not running. Launch it with the BridgeActivity intent first.")
                val s = c.editorSnapshot() ?: return fail(cmd, "NO_FILE_OPEN", "No file is open in the editor")
                return ok(cmd, s)
            }
            "GET_PROJECT_STATUS" -> {
                val p = project(req)
                val o = JSONObject().put("project", p).put("ui_attached", controller != null)
                    .put("files", JSONArray(store.tree(p).filter { !it.isDir }.map { it.path }))
                    .put("trusted", prefs.getBoolean("trusted_$p", false))
                val probs = problemsJson(p); o.put("static_problem_count", probs.length()); o.put("static_problems", probs)
                controller?.let { o.put("ide", it.status()) }
                lastRun?.let { o.put("last_run", it) }
                return ok(cmd, o)
            }
            "VALIDATE_FILE" -> {
                val p = project(req); val path = req.optString("path").ifEmpty { null }
                controller?.flush(p, path)
                return ok(cmd, JSONObject().put("problems", problemsJson(p, path)))
            }
            "CREATE_FILE" -> {
                val p = project(req); val path = req.getString("path")
                if (store.fileExists(p, path) && !req.optBoolean("overwrite")) return fail(cmd, "EXISTS", "File exists. Use APPLY_PATCH or UPDATE_FILE.")
                return ok(cmd, trackedWrite(p, path, req.optString("content"), "CREATE_FILE"))
            }
            "UPDATE_FILE" -> {
                val p = project(req); val path = req.getString("path")
                if (!store.fileExists(p, path)) return fail(cmd, "NOT_FOUND", "File does not exist; use CREATE_FILE")
                return ok(cmd, trackedWrite(p, path, req.getString("content"), "UPDATE_FILE"))
            }
            "APPLY_PATCH" -> {
                val p = project(req); val path = req.getString("file")
                controller?.flush(p, path)
                val old = store.read(p, path)
                val nu = PatchEngine.apply(old, req.getJSONArray("ops"))
                if (nu == old) return fail(cmd, "NO_CHANGE", "Patch produced no change")
                return ok(cmd, trackedWrite(p, path, nu, "APPLY_PATCH"))
            }
            "INSERT_CODE" -> {
                val text = req.getString("text")
                val path = req.optString("path")
                if (path.isEmpty()) {
                    val c = controller ?: return fail(cmd, "NO_UI", "No editor attached; pass 'path' and 'line' for a file-based insert")
                    val snap = c.editorSnapshot() ?: return fail(cmd, "NO_FILE_OPEN", "No file is open")
                    val p = snap.getString("project"); val f = snap.getString("path")
                    c.flush(p, f); store.recordChange(p, f, snap.getString("text"), "INSERT_CODE")
                    if (!c.insertAtCursor(text)) return fail(cmd, "EDIT_FAILED", "Could not insert")
                    c.flush(p, f)
                    return ok(cmd, JSONObject().put("file", f).put("problems", problemsJson(p, f)))
                }
                val p = project(req); controller?.flush(p, path)
                val old = store.read(p, path)
                val lines = old.split("\n").toMutableList()
                val ln = req.optInt("line", lines.size + 1).coerceIn(1, lines.size + 1)
                val col = req.optInt("column", 1).coerceAtLeast(1)
                var off = 0; for (k in 0 until ln - 1) off += lines[k].length + 1
                off = if (ln > lines.size) old.length else off + (col - 1).coerceAtMost(lines[ln - 1].length)
                return ok(cmd, trackedWrite(p, path, old.substring(0, off) + text + old.substring(off), "INSERT_CODE"))
            }
            "REPLACE_SELECTION" -> {
                val c = controller ?: return fail(cmd, "NO_UI", "No editor attached")
                val snap = c.editorSnapshot() ?: return fail(cmd, "NO_FILE_OPEN", "No file is open")
                if (snap.getInt("sel_start") == snap.getInt("sel_end")) return fail(cmd, "NO_SELECTION", "Nothing is selected")
                val p = snap.getString("project"); val f = snap.getString("path")
                c.flush(p, f); store.recordChange(p, f, snap.getString("text"), "REPLACE_SELECTION")
                if (!c.replaceSelection(req.getString("text"))) return fail(cmd, "EDIT_FAILED", "Could not replace")
                c.flush(p, f)
                return ok(cmd, JSONObject().put("file", f).put("problems", problemsJson(p, f)))
            }
            "SAVE_FILE" -> {
                val p = project(req); controller?.flush(p, req.optString("path").ifEmpty { null })
                return ok(cmd, JSONObject().put("saved", true).put("ui_attached", controller != null))
            }
            "DELETE_FILE" -> {
                val p = project(req); val path = req.getString("path")
                if (!approved) { if (!store.resolve(p, path).exists()) return fail(cmd, "NOT_FOUND", "Not found: $path"); needApproval(cmd, req, "Delete '$path' from '$p'", done); return null }
                val f = store.resolve(p, path)
                if (f.isFile && ProjectStore.isText(path)) store.recordChange(p, path, store.read(p, path), "DELETE_FILE") else store.backup(p)
                store.delete(p, path); controller?.reload(p, null)
                return ok(cmd, JSONObject().put("deleted", path))
            }
            "RUN_PROJECT" -> {
                val c = controller ?: return fail(cmd, "NO_UI", "The IDE screen is not running; launch it with the BridgeActivity intent, then retry")
                val p = project(req)
                if (c.project != p) c.openProject(p)
                if (!prefs.getBoolean("trusted_$p", false)) return fail(cmd, "UNTRUSTED_PROJECT", "This project was imported and is not trusted yet. The user must press Run once in the IDE and accept the warning.")
                c.runProject(req.optString("entry").ifEmpty { null }, req.optString("mode").ifEmpty { null }) { run ->
                    run.put("static_problems", problemsJson(p)); lastRun = run
                    log("RUN_PROJECT finished: ${run.optInt("error_count")} error(s)")
                    done(ok(cmd, run))
                }
                return null
            }
            "STOP_PREVIEW" -> { controller?.stopPreview(); return ok(cmd, JSONObject().put("stopped", true)) }
            "GET_CONSOLE", "GET_CONSOLE_ERRORS" -> {
                val c = controller ?: return fail(cmd, "NO_UI", "No preview attached")
                val all = c.console()
                val sel = if (cmd == "GET_CONSOLE_ERRORS") all.filter { it.level == "ERROR" } else all
                val arr = JSONArray(); sel.takeLast(req.optInt("limit", 100).coerceIn(1, 500)).forEach { arr.put(it.toJson()) }
                return ok(cmd, JSONObject().put("entries", arr).put("error_count", all.count { it.level == "ERROR" }))
            }
            "UNDO_LAST_AI_CHANGE" -> {
                val p = project(req)
                controller?.flush(p, null)
                val f = store.undoLastChange(p) ?: return fail(cmd, "NOTHING_TO_UNDO", "No recorded change")
                controller?.reload(p, f)
                return ok(cmd, JSONObject().put("restored", f))
            }
            "LIST_CHANGES" -> {
                val p = project(req); val arr = JSONArray(); store.listChanges(p).take(50).forEach { arr.put(it) }
                return ok(cmd, JSONObject().put("changes", arr))
            }
            else -> return fail(cmd, "UNKNOWN_COMMAND", "Unknown command '$cmd'. See GET_CAPABILITIES.")
        }
    }
}
