package com.lia.htmlstudio

import android.text.Editable
import android.text.Spanned
import android.text.style.ForegroundColorSpan

class SyntaxSpan(color: Int) : ForegroundColorSpan(color)

data class Palette(
    val dark: Boolean,
    val bg: Int, val panel: Int, val panel2: Int, val text: Int, val muted: Int, val accent: Int,
    val gutter: Int, val gutterText: Int, val keyword: Int, val string: Int, val comment: Int,
    val number: Int, val tag: Int, val attr: Int, val error: Int, val match: Int, val selectionLine: Int
)

object Themes {
    val DARK = Palette(true, 0xFF0D1117.toInt(), 0xFF161B22.toInt(), 0xFF21262D.toInt(), 0xFFE6EDF3.toInt(), 0xFF8B949E.toInt(), 0xFF2EA043.toInt(),
        0xFF0D1117.toInt(), 0xFF6E7681.toInt(), 0xFFFF7B72.toInt(), 0xFFA5D6FF.toInt(), 0xFF8B949E.toInt(), 0xFF79C0FF.toInt(),
        0xFF7EE787.toInt(), 0xFFD2A8FF.toInt(), 0x55F85149, 0x663FB950, 0x22FFFFFF)
    val LIGHT = Palette(false, 0xFFFFFFFF.toInt(), 0xFFF6F8FA.toInt(), 0xFFEAEEF2.toInt(), 0xFF1F2328.toInt(), 0xFF656D76.toInt(), 0xFF1A7F37.toInt(),
        0xFFF6F8FA.toInt(), 0xFF8C959F.toInt(), 0xFFCF222E.toInt(), 0xFF0A3069.toInt(), 0xFF6E7781.toInt(), 0xFF0550AE.toInt(),
        0xFF116329.toInt(), 0xFF8250DF.toInt(), 0x44CF222E, 0x661A7F37, 0x14000000)
}

object Highlighter {
    const val MAX_CHARS = 200_000

    fun langOf(path: String): String = when (ProjectStore.ext(path)) {
        "html", "htm" -> "html"
        "css" -> "css"
        "js", "mjs" -> "js"
        "json", "webmanifest" -> "json"
        "svg" -> "html"
        else -> "text"
    }

    private val JS_KW = Regex("\\b(function|return|var|let|const|if|else|for|while|do|switch|case|break|continue|new|this|class|extends|super|import|export|from|default|try|catch|finally|throw|typeof|instanceof|in|of|async|await|yield|null|undefined|true|false|void|delete)\\b")
    private val NUM = Regex("\\b\\d+(\\.\\d+)?\\b|#[0-9a-fA-F]{3,8}\\b")
    private val STR = Regex("\"(\\\\.|[^\"\\\\\\n])*\"|'(\\\\.|[^'\\\\\\n])*'|`[^`]*`")
    private val C_COMMENT = Regex("/\\*[\\s\\S]*?\\*/|//[^\\n]*")
    private val HTML_COMMENT = Regex("<!--[\\s\\S]*?-->")
    private val HTML_TAG = Regex("</?[A-Za-z][A-Za-z0-9:-]*|/?>|<!DOCTYPE|<!doctype")
    private val HTML_ATTR = Regex("\\s([A-Za-z_:][A-Za-z0-9_:.-]*)(?==)")
    private val CSS_PROP = Regex("([A-Za-z-]+)\\s*(?=:)")
    private val CSS_SEL = Regex("[.#][A-Za-z_][A-Za-z0-9_-]*|@[a-z-]+")
    private val JSON_KEY = Regex("\"(\\\\.|[^\"\\\\])*\"(?=\\s*:)")

    fun clear(e: Editable) { for (s in e.getSpans(0, e.length, SyntaxSpan::class.java)) e.removeSpan(s) }

    fun apply(e: Editable, lang: String, p: Palette) {
        clear(e)
        if (e.length > MAX_CHARS || lang == "text") return
        val s = e.toString()
        fun mark(r: Regex, color: Int, group: Int = 0) {
            for (m in r.findAll(s)) {
                val g = if (group == 0) m.range else (m.groups[group]?.range ?: continue)
                e.setSpan(SyntaxSpan(color), g.first, g.last + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        when (lang) {
            "js" -> { mark(NUM, p.number); mark(JS_KW, p.keyword); mark(STR, p.string); mark(C_COMMENT, p.comment) }
            "css" -> { mark(CSS_PROP, p.attr, 1); mark(CSS_SEL, p.tag); mark(NUM, p.number); mark(STR, p.string); mark(C_COMMENT, p.comment) }
            "json" -> { mark(NUM, p.number); mark(Regex("\\b(true|false|null)\\b"), p.keyword); mark(STR, p.string); mark(JSON_KEY, p.attr) }
            "html" -> {
                mark(HTML_TAG, p.tag); mark(HTML_ATTR, p.attr, 1); mark(STR, p.string)
                if (lang == "html") markEmbedded(e, s, p)
                mark(HTML_COMMENT, p.comment)
            }
        }
    }

    /** Highlights the content of <script> and <style> blocks inside HTML with JS/CSS rules. */
    private fun markEmbedded(e: Editable, s: String, p: Palette) {
        fun block(tag: String, lang: String) {
            val r = Regex("<$tag\\b[^>]*>([\\s\\S]*?)</$tag>", RegexOption.IGNORE_CASE)
            for (m in r.findAll(s)) {
                val g = m.groups[1] ?: continue
                if (g.value.isEmpty()) continue
                val sub = android.text.SpannableStringBuilder(g.value)
                apply(sub, lang, p)
                for (sp in sub.getSpans(0, sub.length, SyntaxSpan::class.java)) {
                    val a = sub.getSpanStart(sp); val b = sub.getSpanEnd(sp)
                    e.setSpan(SyntaxSpan(sp.foregroundColor), g.range.first + a, g.range.first + b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
        }
        block("script", "js"); block("style", "css")
    }
}
