package com.lia.htmlstudio

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor

/**
 * call("execute", jsonString) -> Bundle{"response": jsonString}   (synchronous command API)
 * content://com.lia.htmlstudio.lia/file/<project>/<path>?token=<pairing token>  -> read-only file stream
 * No shell access, no path outside <project>, no write access through URIs.
 */
class LiaProvider : ContentProvider() {
    override fun onCreate(): Boolean { LiaApi.init(context!!); return true }

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        LiaApi.init(context!!)
        val b = Bundle()
        if (method != "execute" || arg == null) {
            b.putString("response", LiaApi.fail("?", "BAD_CALL", "Use call(\"execute\", jsonString)").toString()); return b
        }
        val timeout = if (arg.contains("RUN_PROJECT")) 25_000L else 15_000L
        b.putString("response", LiaApi.executeBlocking(arg, timeout).toString())
        return b
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        LiaApi.init(context!!)
        if (mode != "r") throw SecurityException("Read-only")
        val tok = uri.getQueryParameter("token") ?: throw SecurityException("token required")
        if (!java.security.MessageDigest.isEqual(tok.toByteArray(), LiaApi.token().toByteArray())) throw SecurityException("bad token")
        val seg = uri.pathSegments
        if (seg.size < 3 || seg[0] != "file") throw java.io.FileNotFoundException("expected /file/<project>/<path>")
        val project = seg[1]; val rel = seg.drop(2).joinToString("/")
        val f = try { LiaApi.store.resolve(project, rel) } catch (e: StoreException) { throw SecurityException(e.message) }
        if (!f.isFile) throw java.io.FileNotFoundException(rel)
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun query(u: Uri, p: Array<String>?, s: String?, a: Array<String>?, o: String?): Cursor? = null
    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<String>?) = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<String>?) = 0
}
