package com.lia.htmlstudio

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

data class Problem(val line: Int, val column: Int, val severity: String, val message: String) {
    fun toJson(): JSONObject {
        val (en, hi) = Explain.explain(message)
        return JSONObject().put("line", line).put("column", column).put("severity", severity)
            .put("message", message).put("explain_en", en).put("explain_hi", hi)
    }
}

/** Bilingual (English / Hindi) explanations for the most common web errors. Falls back to the raw message. */
object Explain {
    private val rules: List<Triple<Regex, String, String>> = listOf(
        Triple(Regex("is not defined", RegexOption.IGNORE_CASE),
            "A variable or function is used but was never declared. Check spelling, or declare it (let/const/function) before using it; also check the <script> load order.",
            "Aap ek variable ya function use kar rahe hain jo declare nahi hua. Spelling check karein, ya use pehle declare karein (let/const/function); <script> ka order bhi dekhein."),
        Triple(Regex("Cannot read propert(y|ies) of (null|undefined)|null is not an object|undefined is not an object", RegexOption.IGNORE_CASE),
            "You are accessing a property on null/undefined. Usually getElementById returned null (wrong id, or script runs before the element exists). Put the script at the end of <body> or use DOMContentLoaded.",
            "Aap null/undefined par property access kar rahe hain. Aksar getElementById null deta hai (galat id ya script element se pehle chal gayi). Script ko </body> se pehle rakhein ya DOMContentLoaded use karein."),
        Triple(Regex("is not a function", RegexOption.IGNORE_CASE),
            "The thing you are calling is not a function. Check the name, and that the value really is a function.",
            "Jise aap call kar rahe hain wo function nahi hai. Naam aur value ka type check karein."),
        Triple(Regex("Unexpected token|SyntaxError|Unexpected identifier|Invalid or unexpected", RegexOption.IGNORE_CASE),
            "Syntax error: a character is in the wrong place. Look at this line and the one before it for a missing comma, bracket, quote or semicolon.",
            "Syntax error: koi character galat jagah hai. Is line aur pichhli line mein missing comma, bracket, quote ya semicolon dekhein."),
        Triple(Regex("Unexpected end of input|Unclosed|never closed|unclosed", RegexOption.IGNORE_CASE),
            "Something was opened but never closed ( { [ ( or a tag or a string). Add the matching closing character.",
            "Kuch khola gaya par band nahi hua ( { [ ( ya tag ya string). Matching closing character lagayein."),
        Triple(Regex("Unexpected closing|Mismatched|unmatched", RegexOption.IGNORE_CASE),
            "A closing bracket/tag has no matching opener, or it does not match the one that is open.",
            "Closing bracket/tag ka koi matching opening nahi hai, ya wo khule hue se match nahi karta."),
        Triple(Regex("Failed to load resource|404|ERR_FILE_NOT_FOUND|not found", RegexOption.IGNORE_CASE),
            "A file (script, stylesheet, image) could not be found. Check the path and file name (case matters) relative to the HTML file.",
            "Koi file (script, css, image) nahi mili. HTML file ke relative path aur file ka naam (capital/small letter) check karein."),
        Triple(Regex("JSON|Unexpected character", RegexOption.IGNORE_CASE),
            "Invalid JSON: keys and strings need double quotes, no trailing commas, no comments.",
            "JSON galat hai: key aur string double quotes mein hone chahiye, aakhri comma nahi, comments nahi."),
        Triple(Regex("Assignment to constant", RegexOption.IGNORE_CASE),
            "A const variable cannot be reassigned. Use let instead.",
            "const variable ko dobara value nahi de sakte. let use karein."),
        Triple(Regex("already been declared", RegexOption.IGNORE_CASE),
            "The same name is declared twice in the same scope (let/const). Rename one.",
            "Ek hi naam same scope mein do baar declare hua hai. Ek ka naam badlein.")
    )

    fun explain(msg: String): Pair<String, String> {
        for ((r, en, hi) in rules) if (r.containsMatchIn(msg)) return en to hi
        return "No built-in explanation for this message; read it together with the line number shown." to
            "Is message ki koi built-in vyakhya nahi hai; line number ke saath message ko padhein."
    }
}

object Validator {
    private val VOID = setOf("area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr", "!doctype")

    fun validate(path: String, text: String): List<Problem> {
        if (text.length > 1_500_000) return emptyList()
        return when (Highlighter.langOf(path)) {
            "json" -> json(text)
            "html" -> html(text, true)
            "css" -> brackets(text, cStyle = true)
            "js" -> brackets(text, cStyle = true)
            else -> emptyList()
        }
    }

    private fun lineCol(text: String, offset: Int): Pair<Int, Int> {
        var line = 1; var last = -1
        val o = offset.coerceIn(0, text.length)
        for (i in 0 until o) if (text[i] == '\n') { line++; last = i }
        return line to (o - last)
    }

    private fun json(text: String): List<Problem> {
        if (text.isBlank()) return emptyList()
        return try {
            val tk = JSONTokener(text)
            tk.nextValue()
            // JSONTokener silently ignores trailing garbage, so check that only whitespace follows the value.
            if (tk.more() && tk.nextClean() != 0.toChar()) {
                val (l, c) = lineCol(text, tk.toString().substringAfter("at character ", "0").substringBefore(" ").toIntOrNull() ?: 0)
                listOf(Problem(l, c, "error", "JSON: unexpected data after the end of the value"))
            } else emptyList()
        } catch (e: org.json.JSONException) {
            val off = Regex("at character (\\d+)").find(e.message ?: "")?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val (l, c) = lineCol(text, off)
            listOf(Problem(l, c, "error", "JSON: " + (e.message ?: "invalid")))
        }
    }

    /** Bracket balance for JavaScript and CSS, skipping strings and comments. */
    private fun brackets(text: String, cStyle: Boolean): List<Problem> {
        val out = ArrayList<Problem>()
        val stack = ArrayList<Triple<Char, Int, Int>>()
        var i = 0; var line = 1; var col = 0
        fun adv(c: Char) { if (c == '\n') { line++; col = 0 } else col++ }
        while (i < text.length) {
            val c = text[i]
            val n = if (i + 1 < text.length) text[i + 1] else '\u0000'
            if (cStyle && c == '/' && n == '/') { while (i < text.length && text[i] != '\n') { i++; col++ }; continue }
            if (cStyle && c == '/' && n == '*') {
                val sl = line; val sc = col
                val end = text.indexOf("*/", i + 2)
                if (end < 0) { out.add(Problem(sl, sc + 1, "error", "Unclosed comment /* ... */")); return out }
                while (i < end + 2) { adv(text[i]); i++ }; continue
            }
            if (!cStyle && c == '#') { while (i < text.length && text[i] != '\n') { i++; col++ }; continue }
            if (c == '"' || c == '\'' || (cStyle && c == '`')) {
                val q = c; val sl = line; val sc = col; adv(c); i++
                var closed = false
                while (i < text.length) {
                    val d = text[i]
                    if (d == '\\') { adv(d); i++; if (i < text.length) { adv(text[i]); i++ }; continue }
                    if (d == '\n' && q != '`') break
                    adv(d); i++
                    if (d == q) { closed = true; break }
                }
                if (!closed) out.add(Problem(sl, sc + 1, "error", "Unclosed string (missing closing $q)"))
                continue
            }
            if (c == '(' || c == '[' || c == '{') stack.add(Triple(c, line, col + 1))
            else if (c == ')' || c == ']' || c == '}') {
                val open = stack.lastOrNull()
                val want = when (c) { ')' -> '('; ']' -> '['; else -> '{' }
                if (open == null) out.add(Problem(line, col + 1, "error", "Unexpected closing '$c' (nothing is open)"))
                else if (open.first != want) { out.add(Problem(line, col + 1, "error", "Mismatched '$c' — the open '${open.first}' from line ${open.second} is not closed yet")); stack.removeAt(stack.size - 1) }
                else stack.removeAt(stack.size - 1)
            }
            adv(c); i++
        }
        for (o in stack) out.add(Problem(o.second, o.third, "error", "Unclosed '${o.first}' (never closed)"))
        return out.take(50)
    }

    private fun html(text: String, isHtml: Boolean): List<Problem> {
        val out = ArrayList<Problem>()
        val stack = ArrayList<Triple<String, Int, Int>>()
        val re = Regex("<!--[\\s\\S]*?-->|<(/?)([A-Za-z!][A-Za-z0-9:_-]*)((?:\"[^\"]*\"|'[^']*'|[^'\">])*?)(/?)>", RegexOption.IGNORE_CASE)
        var pos = 0
        while (pos < text.length) {
            val m = re.find(text, pos) ?: break
            pos = m.range.last + 1
            if (m.value.startsWith("<!--")) continue
            val closing = m.groupValues[1] == "/"
            val name = m.groupValues[2].lowercase()
            val selfClose = m.groupValues[4] == "/"
            val (l, c) = lineCol(text, m.range.first)
            if (isHtml && !closing && (name == "script" || name == "style") && !selfClose) {
                val end = Regex("</$name\\s*>", RegexOption.IGNORE_CASE).find(text, pos)
                if (end == null) { out.add(Problem(l, c, "error", "Unclosed <$name> tag")); return out }
                pos = end.range.last + 1; continue
            }
            if (name == "!doctype" || (isHtml && name in VOID) || selfClose) continue
            if (!closing) stack.add(Triple(name, l, c))
            else {
                val idx = stack.indexOfLast { it.first == name }
                if (idx < 0) out.add(Problem(l, c, "error", "Unexpected closing tag </$name> (no matching opening tag)"))
                else {
                    for (k in stack.size - 1 downTo idx + 1) {
                        val s = stack[k]
                        if (!(isHtml && s.first in setOf("p", "li", "td", "th", "tr", "dt", "dd", "option", "tbody", "thead")))
                            out.add(Problem(s.second, s.third, "error", "Unclosed tag <${s.first}> (closed implicitly by </$name>)"))
                    }
                    while (stack.size > idx) stack.removeAt(stack.size - 1)
                }
            }
        }
        for (s in stack) if (!(isHtml && s.first in setOf("p", "li", "html", "body", "head"))) out.add(Problem(s.second, s.third, "error", "Unclosed tag <${s.first}>"))
        return out.take(50)
    }
}

/** Basic re-indenter (not a full pretty-printer). Always undoable from the editor. */
object Formatter {
    fun format(path: String, text: String): String = when (Highlighter.langOf(path)) {
        "json" -> runCatching {
            val v = JSONTokener(text).nextValue()
            when (v) { is JSONObject -> v.toString(2) + "\n"; is JSONArray -> v.toString(2) + "\n"; else -> text }
        }.getOrDefault(text)
        "js", "css" -> indentBraces(text)
        "html" -> indentHtml(text)
        else -> text.lines().joinToString("\n") { it.trimEnd() }
    }

    private fun braceDelta(line: String): Pair<Int, Int> { // (leadingCloses, netAfterLeading)
        var inStr = 0.toChar(); var lead = 0; var seenOther = false; var net = 0; var i = 0
        while (i < line.length) {
            val c = line[i]
            if (inStr != 0.toChar()) { if (c == '\\') i++ else if (c == inStr) inStr = 0.toChar() }
            else if (c == '"' || c == '\'' || c == '`') { inStr = c; seenOther = true }
            else if (c == '/' && i + 1 < line.length && line[i + 1] == '/') break
            else if (c == '{' || c == '[' || c == '(') { net++; seenOther = true }
            else if (c == '}' || c == ']' || c == ')') { if (!seenOther) lead++ else net-- }
            else if (!c.isWhitespace()) seenOther = true
            i++
        }
        return lead to net
    }

    private fun indentBraces(text: String): String {
        var depth = 0; val sb = StringBuilder(); var inBlockComment = false
        for (raw in text.lines()) {
            val line = raw.trim()
            if (inBlockComment) { sb.append("  ".repeat(depth)).append(" ").append(line).append('\n'); if (line.contains("*/")) inBlockComment = false; continue }
            if (line.isEmpty()) { sb.append('\n'); continue }
            if (line.startsWith("/*") && !line.contains("*/")) inBlockComment = true
            val (lead, net) = braceDelta(line)
            depth = (depth - lead).coerceAtLeast(0)
            sb.append("  ".repeat(depth)).append(line).append('\n')
            depth = (depth + net + 0).coerceAtLeast(0)
        }
        return sb.toString().trimEnd('\n') + "\n"
    }

    private fun indentHtml(text: String): String {
        val void = setOf("area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr", "!doctype")
        val tagRe = Regex("<(/?)([A-Za-z!][A-Za-z0-9:_-]*)[^>]*?(/?)>")
        var depth = 0; val sb = StringBuilder(); var raw = ""
        for (rawLine in text.lines()) {
            val line = rawLine.trim()
            if (raw.isNotEmpty()) { // inside <pre>/<textarea>: keep untouched
                sb.append(rawLine).append('\n'); if (line.contains("</$raw")) raw = ""; continue
            }
            if (line.isEmpty()) { sb.append('\n'); continue }
            var d = 0; var lead = 0; var first = true
            for (m in tagRe.findAll(line)) {
                val closing = m.groupValues[1] == "/"; val name = m.groupValues[2].lowercase(); val self = m.groupValues[3] == "/"
                if (name in void || self) { first = false; continue }
                if (closing) { d--; if (first && m.range.first == 0) lead++ } else d++
                first = false
            }
            if (line.startsWith("<pre") || line.startsWith("<textarea")) { val nm = if (line.startsWith("<pre")) "pre" else "textarea"; if (!line.contains("</$nm")) raw = nm }
            depth = (depth - lead).coerceAtLeast(0)
            sb.append("  ".repeat(depth)).append(line).append('\n')
            depth = (depth + d + lead).coerceAtLeast(0)
        }
        return sb.toString().trimEnd('\n') + "\n"
    }
}
