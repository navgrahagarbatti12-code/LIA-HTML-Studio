# Accessibility-based control (fallback)

LIA AI's own `AccessibilityService` drives this IDE's visible UI. **This app does not ship an AccessibilityService** —
it only has to be operable, and it is: every control carries a stable `contentDescription` (and visible text).
Prefer the direct API (`LIA_INTEGRATION.md`); use this when you need to press something the API does not cover.

## Stable node descriptions (find with `findAccessibilityNodeInfosByText` or by contentDescription)
| Control | contentDescription |
|---|---|
| Open/close project explorer | `Explorer` |
| New file / New folder / Refresh (explorer header) | `New file`, `New folder`, `Refresh explorer` |
| Explorer rows | `File: <path>` , `Folder: <path>` (click = open/toggle, long-click = actions) |
| File tabs / close | `Tab: <path>` , `Close tab <path>` |
| Undo / Redo / Find / Save | `Undo`, `Redo`, `Find`, `Save file` |
| Run / Stop | `Run project`, `Stop preview` |
| Overflow menu | `More options` (menu items are text: "Format document", "Settings", …) |
| View switch | `Code view`, `Split view`, `Preview view` |
| Bottom panels | `Console`, `Problems`, `Close panel`, `Clear console` |
| Editor | `Code editor` (class EditText: supports `ACTION_SET_SELECTION`, `ACTION_SET_TEXT`, `ACTION_PASTE`, `ACTION_SCROLL_*`) |
| Console / problems content | `Console output`, `Problems list`; each line's description is `LEVEL: message (file:line)` / `Problem line N: message` |
| Find bar | `Find input`, `Replace input`, `Find next`, `Find previous`, `Replace`, `Replace all`, `Match case`, `Close find` |
| Status line | `Status` (last action / last error) |

## Typical operations
* Open explorer → click `Explorer`; select a file → click `File: js/game.js`; switch tab → click `Tab: css/style.css`.
* Place cursor / select code → focus `Code editor`, `ACTION_SET_SELECTION` with start/end.
* Press Run → click `Run project`; read result → read nodes under `Console output` / `Problems list`, or the `Status` text.
* Read an error's explanation (EN/HI): click an `ERROR:` console line → dialog with both explanations.

## Limits (be honest in LIA's UI)
* The user must enable LIA's accessibility service in Android settings. Android may restrict this on some devices/Play policies.
* Dialogs raised by the IDE (delete confirmation, approvals, untrusted-code warning) are meant for the human; LIA should not auto-click
  "Allow" on its own approval requests.
* Editor text is only partially exposed by Android for very large files; use `READ_FILE` for full content.
