# LIA AI ⇄ LIA HTML Studio integration (API v2)

Primary control path. Accessibility control (see `ACCESSIBILITY.md`) is only a fallback.

## 1. Pairing token
Every command must carry the token shown in the IDE under **⋮ → Settings → LIA integration — pairing token**
(Copy / Regenerate). Without it, calls fail with `UNAUTHORIZED`. Store it in LIA's own private storage. Regenerating revokes the old one.

## 2. Transport A — ContentProvider (synchronous, returns the result)
Authority: `com.lia.htmlstudio.lia`

```kotlin
val req = JSONObject()
    .put("token", token)
    .put("command", "APPLY_PATCH")
    .put("project", "Car Game")
    .put("file", "js/game.js")
    .put("ops", JSONArray().put(JSONObject()
        .put("type", "replace_function").put("name", "update")
        .put("text", "function update() {\n  score++;\n  moveEnemies();\n}")))
val out = contentResolver.call(Uri.parse("content://com.lia.htmlstudio.lia"), "execute", req.toString(), null)
val resp = JSONObject(out!!.getString("response"))
```
Android 11+: LIA needs `<queries><package android:name="com.lia.htmlstudio"/></queries>` (or `<provider android:authorities="com.lia.htmlstudio.lia"/>`) in its manifest.

Read-only file URI (token in query): `content://com.lia.htmlstudio.lia/file/<project>/<path>?token=<token>`

Commands that need the visible editor/preview (`GET_CURRENT_FILE`, `REPLACE_SELECTION`, cursor-based `INSERT_CODE`, `RUN_PROJECT`, console commands)
return `NO_UI` when the IDE screen is not running. Launch it first (Transport B), then retry. File-only commands work headless.

## 3. Transport B — Intent (launches the IDE, fire-and-forget or startActivityForResult)
```kotlin
val i = Intent("com.lia.htmlstudio.action.COMMAND").apply {
    setClassName("com.lia.htmlstudio", "com.lia.htmlstudio.BridgeActivity")
    putExtra("command_json", req.toString())   // JSON incl. token
    putExtra("show_ui", true)                  // false = execute without opening the IDE
}
startActivityForResult(i, 42)   // result extra "response" = response JSON
```
Legacy actions (`NEW_PROJECT`, `INSERT_CODE`, `REPLACE_ALL`, `RUN_PREVIEW`) still work but **now require the extra `token`**
(previously any app could overwrite your document). `REPLACE_ALL` now maps to `UPDATE_FILE` on the current file (undoable).

## 4. Response format
```json
{"ok":true,"command":"APPLY_PATCH","result":{...}}
{"ok":false,"command":"APPLY_PATCH","error":{"code":"PATCH_FAILED","message":"op #0: Text matches 3 places; ...","op_index":0}}
{"ok":false,"command":"DELETE_FILE","status":"pending_approval","approval_id":"a1b2c3","message":"..."}
```
Error codes: `UNAUTHORIZED BAD_JSON BAD_REQUEST UNKNOWN_COMMAND NO_PROJECT PROJECT_NOT_FOUND PROJECT_EXISTS NOT_FOUND EXISTS INVALID_PATH PATH_ESCAPE
INVALID_NAME TOO_LARGE NOT_TEXT NO_UI NO_FILE_OPEN NO_SELECTION PATCH_FAILED NO_CHANGE UNTRUSTED_PROJECT DENIED TIMEOUT INTERNAL`.

## 5. Commands
| Command | Fields | Notes |
|---|---|---|
| `GET_CAPABILITIES` | – | api_version, command list, what can/cannot execute |
| `LIST_PROJECTS` | – | |
| `CREATE_PROJECT` | `name`, `template` (html/game/blank), `files` {path:content}, `auto_rename`, `overwrite` | `overwrite:true` needs **user approval** (a backup ZIP is made first). Created projects are trusted. |
| `OPEN_PROJECT` | `project` | switches the visible IDE |
| `LIST_FILES` | `project?` | |
| `READ_FILE` | `path`, `start_line?`, `end_line?` | flushes unsaved editor text first |
| `GET_CURRENT_FILE` | – | path, full text, selection, selected_text, cursor_line, open_tabs |
| `INSERT_CODE` | `text` (+ `path`, `line`, `column` for file-based; omit path = at cursor) | |
| `REPLACE_SELECTION` | `text` | |
| `APPLY_PATCH` | `file`, `ops[]` | targeted edit, all-or-nothing, see §6 |
| `CREATE_FILE` | `path`, `content`, `overwrite?` | refuses to overwrite by default |
| `UPDATE_FILE` | `path`, `content` | whole-file replace of ONE file (undoable). Prefer `APPLY_PATCH`. |
| `DELETE_FILE` | `path` | **needs user approval** |
| `SAVE_FILE` | `path?` | flushes editor to disk |
| `RUN_PROJECT` | `entry?`, `mode?` (mobile/desktop) | loads preview, waits ~1.2 s after load, returns `error_count`, `errors[]` (with EN/HI explanations), `static_problems[]`. Imported projects return `UNTRUSTED_PROJECT` until the user presses Run once. |
| `STOP_PREVIEW` | – | |
| `GET_CONSOLE` / `GET_CONSOLE_ERRORS` | `limit?` | live console incl. errors after the run window |
| `VALIDATE_FILE` | `path?` | static checks (brackets, tags, JSON, strings), line numbers |
| `GET_PROJECT_STATUS` | – | files, static problems, IDE state, last run |
| `LIST_CHANGES` / `UNDO_LAST_AI_CHANGE` | – | every write by LIA is recorded and can be reverted |
| `GET_APPROVAL_STATUS` | `approval_id` | poll after `pending_approval`; `result` holds the final response once the user allowed it |
| `GET_LAST_RESPONSE` | – | last response (useful after an Intent call) |

## 6. Patch operations (`APPLY_PATCH`)
Applied in order to an in-memory copy; if any op fails nothing is written.
```
{"type":"replace_text","find":"…","replace":"…","occurrence":2|"all"}   find must be unique unless occurrence is given
{"type":"insert_after","anchor":"…","text":"…"}  /  {"type":"insert_before",…}   anchor must be unique
{"type":"replace_function","name":"update","text":"function update(){…}"}   JS function / arrow const / method, brace-matched
{"type":"replace_lines","start":10,"end":12,"text":"…"}                  1-based inclusive
{"type":"set_css_property","selector":".car","property":"width","value":"60px"}   edits, adds, or creates the rule
{"type":"append","text":"…"}  /  {"type":"prepend","text":"…"}
```
Success result: `{file, diff:{lines_added, lines_removed, first_changed_line, removed[], added[]}, problems[], note}`.
`problems` is a static check only.

## 7. Recommended loop for "add an enemy car"
1. `GET_PROJECT_STATUS` → file list. 2. `READ_FILE` the relevant files. 3. `APPLY_PATCH` (targeted ops).
4. `RUN_PROJECT`. 5. Read `errors[]`. If non-empty: patch again, `RUN_PROJECT` again.
6. Report to the user **only** what the last `RUN_PROJECT` result actually says. `problems:[]` from a patch is not proof the game works.
7. If it went wrong: `UNDO_LAST_AI_CHANGE` (repeat per file).

## 8. Safety rules enforced by the IDE
Token on every call · all paths validated against the project folder (`..`, absolute paths rejected) · no shell, no arbitrary filesystem ·
delete & project replacement need an on-screen Allow/Deny · imported ZIP/folder projects are untrusted until the user runs them once ·
every LIA action appears in **⋮ → LIA activity**.
