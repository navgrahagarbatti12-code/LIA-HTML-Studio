package com.lia.htmlstudio

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ClipData
import android.content.ContentValues
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.MediaStore
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.Executors

class Tab(val path: String) { var cursor = 0; var dirty = false }

/**
 * LIA HTML Studio IDE screen. Implements [IdeController] so that LIA AI (via [LiaApi]) can drive the visible editor.
 * Accessibility: every control has a stable contentDescription (see docs/ACCESSIBILITY.md).
 */
class MainActivity : ComponentActivity(), IdeController {
    // ---------- state ----------
    private lateinit var store: ProjectStore
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var pal: Palette
    private val ui = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()

    override var project: String? = null
    private val tabs = ArrayList<Tab>()
    private var cur: Tab? = null
    private val expanded = HashSet<String>()

    private lateinit var root: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var explorerPanel: LinearLayout
    private lateinit var explorerList: LinearLayout
    private lateinit var tabsBar: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var editorFrame: FrameLayout
    private lateinit var editor: EditorView
    private lateinit var dashboard: ScrollView
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var replInput: EditText
    private lateinit var findCase: CheckBox
    private lateinit var preview: WebView
    private lateinit var previewFrame: FrameLayout
    private lateinit var bottomPanel: LinearLayout
    private lateinit var consoleScroll: ScrollView
    private lateinit var consoleBox: LinearLayout
    private lateinit var problemsScroll: ScrollView
    private lateinit var problemsBox: LinearLayout
    private lateinit var statusView: TextView
    private lateinit var modeButtons: Map<String, TextView>
    private lateinit var consoleBtn: TextView
    private lateinit var problemsBtn: TextView
    private lateinit var undoBtn: TextView
    private lateinit var redoBtn: TextView

    private var viewMode = "split"                 // code | preview | split
    private var bottomMode = "none"                // none | console | problems
    private val consoleEntries = ArrayList<ConsoleEntry>()
    private var staticLines = emptySet<Int>()
    private var runtimeLines = emptySet<Int>()
    private var staticProblems = emptyList<Problem>()
    private var runningEntry: String? = null
    private var pendingRun: ((JSONObject) -> Unit)? = null
    private var runToken = 0
    private var desktopMode = false
    private var approvalDialog: AlertDialog? = null
    private var pickerDest = ""                    // destination folder for file imports

    private lateinit var assetLoader: WebViewAssetLoader

    // ---------- SAF launchers ----------
    private val importZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { doImportZip(it) } }
    private val exportZip = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri -> uri?.let { doExportZip(it) } }
    private val importTree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let { doImportTree(it) } }
    private val importFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if (uris.isNotEmpty()) doImportFiles(uris) }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LiaApi.init(this)
        store = LiaApi.store; prefs = LiaApi.prefs
        pal = if (prefs.getString("theme", "dark") == "light") Themes.LIGHT else Themes.DARK
        buildUi()
        restoreSession()
        LiaApi.controller = this
    }

    override fun onResume() {
        super.onResume()
        LiaApi.controller = this
        notifyApprovals()
    }

    override fun onPause() {
        super.onPause()
        saveCurrentIfDirty(); persistSession()
    }

    override fun onDestroy() {
        if (LiaApi.controller === this) LiaApi.controller = null
        ui.removeCallbacksAndMessages(null)
        runCatching { preview.stopLoading(); (preview.parent as? ViewGroup)?.removeView(preview); preview.destroy() }
        bg.shutdown()
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent)
        notifyApprovals()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            findBar.visibility == View.VISIBLE -> findBar.visibility = View.GONE
            bottomMode != "none" -> setBottom("none")
            explorerPanel.visibility == View.VISIBLE && !isWide() -> explorerPanel.visibility = View.GONE
            else -> { saveCurrentIfDirty(); @Suppress("DEPRECATION") super.onBackPressed() }
        }
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.isCtrlPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_S -> { saveCurrentIfDirty(); toast("Saved"); return true }
                KeyEvent.KEYCODE_F -> { toggleFind(); return true }
                KeyEvent.KEYCODE_R -> { runFromUi(); return true }
                KeyEvent.KEYCODE_G -> { gotoLineDialog(); return true }
                KeyEvent.KEYCODE_B -> { toggleExplorer(); return true }
                KeyEvent.KEYCODE_L -> if (e.isShiftPressed) { formatCurrent(); return true }
            }
        }
        if (e.action == KeyEvent.ACTION_DOWN && e.keyCode == KeyEvent.KEYCODE_F5) { runFromUi(); return true }
        return super.dispatchKeyEvent(e)
    }

    // ---------- small UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun isWide() = resources.configuration.screenWidthDp >= 720
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun tv(text: String, sizeSp: Float = 14f, color: Int = pal.text, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = sizeSp; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(label: String, desc: String, bgc: Int = 0, fg: Int = pal.text, onClick: () -> Unit) = TextView(this).apply {
        text = label; contentDescription = desc; gravity = Gravity.CENTER; textSize = 15f; setTextColor(fg)
        minWidth = dp(44); minHeight = dp(44); setPadding(dp(10), dp(6), dp(10), dp(6))
        if (bgc != 0) background = GradientDrawable().apply { setColor(bgc); cornerRadius = dp(8).toFloat() }
        isClickable = true; isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun prompt(title: String, hint: String, initial: String = "", ok: (String) -> Unit) {
        val et = EditText(this).apply { setText(initial); this.hint = hint; setSingleLine(); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle(title).setView(wrap(et)).setPositiveButton("OK") { _, _ -> ok(et.text.toString().trim()) }.setNegativeButton("Cancel", null).show()
    }

    private fun wrap(v: View) = FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(v) }

    private fun err(e: Throwable) {
        val m = (e as? StoreException)?.message ?: "${e.javaClass.simpleName}: ${e.message}"
        AlertDialog.Builder(this).setTitle("Error").setMessage(m).setPositiveButton("OK", null).show()
    }

    // ---------- UI construction ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.panel) }
        root.setOnApplyWindowInsetsListener { v, ins ->
            @Suppress("DEPRECATION")
            if (Build.VERSION.SDK_INT >= 30) {
                val sb = ins.getInsets(WindowInsets.Type.systemBars()); val ime = ins.getInsets(WindowInsets.Type.ime())
                v.setPadding(sb.left, sb.top, sb.right, maxOf(sb.bottom, ime.bottom))
            } else v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            ins
        }

        // top bar
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(pal.panel); setPadding(dp(4), 0, dp(4), 0) }
        top.addView(button("☰", "Explorer", fg = pal.text) { toggleExplorer() })
        titleView = tv("LIA HTML Studio", 15f, pal.text, true).apply { setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END; contentDescription = "Current project and file" }
        top.addView(titleView, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
        undoBtn = button("↶", "Undo") { editor.undo() }; redoBtn = button("↷", "Redo") { editor.redo() }
        top.addView(undoBtn); top.addView(redoBtn)
        top.addView(button("🔍", "Find") { toggleFind() })
        top.addView(button("💾", "Save file") { saveCurrentIfDirty(); toast("Saved") })
        top.addView(button("▶", "Run project", pal.accent, Color.WHITE) { runFromUi() })
        top.addView(button("■", "Stop preview") { stopPreview() })
        top.addView(button("📷", "Capture preview screenshot") { capturePreviewScreenshot() })
        top.addView(button("⋮", "More options") {}.also { b -> b.setOnClickListener { showMenu(b) } })
        root.addView(top, LinearLayout.LayoutParams(-1, dp(52)))

        // body = explorer + main column
        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        explorerPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.panel2); visibility = if (isWide()) View.VISIBLE else View.GONE }
        val exHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, 0, 0) }
        exHead.addView(tv("EXPLORER", 12f, pal.muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        exHead.addView(button("＋", "New file") { newFileDialog("") })
        exHead.addView(button("📁", "New folder") { newFolderDialog("") })
        exHead.addView(button("⟳", "Refresh explorer") { buildExplorer() })
        explorerPanel.addView(exHead, LinearLayout.LayoutParams(-1, dp(44)))
        explorerList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; contentDescription = "Project explorer" }
        explorerPanel.addView(ScrollView(this).apply { addView(explorerList) }, LinearLayout.LayoutParams(-1, 0, 1f))
        body.addView(explorerPanel, LinearLayout.LayoutParams(dp(if (isWide()) 260 else 230), -1))

        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.bg) }
        tabsBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        main.addView(HorizontalScrollView(this).apply { setBackgroundColor(pal.panel2); isHorizontalScrollBarEnabled = false; addView(tabsBar); contentDescription = "File tabs" }, LinearLayout.LayoutParams(-1, dp(40)))

        findBar = buildFindBar(); findBar.visibility = View.GONE
        main.addView(findBar)

        content = LinearLayout(this).apply { orientation = if (isWide()) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL }
        editorFrame = FrameLayout(this)
        editor = EditorView(this).apply { contentDescription = "Code editor"; autoClose = prefs.getBoolean("auto_close", true) }
        editor.applyStyle(pal, prefs.getFloat("font_size", 14f), fontFace())
        editor.onUserChange = { onEditorChanged() }
        editorFrame.addView(editor, FrameLayout.LayoutParams(-1, -1))
        dashboard = buildDashboard()
        editorFrame.addView(dashboard, FrameLayout.LayoutParams(-1, -1))
        content.addView(editorFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        previewFrame = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        preview = WebView(this).apply { contentDescription = "Live preview" }
        configurePreview()
        previewFrame.addView(preview, FrameLayout.LayoutParams(-1, -1))
        content.addView(previewFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        // bottom panel (console / problems)
        bottomPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.panel); visibility = View.GONE }
        consoleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; contentDescription = "Console output" }
        problemsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; contentDescription = "Problems list" }
        consoleScroll = ScrollView(this).apply { addView(consoleBox) }
        problemsScroll = ScrollView(this).apply { addView(problemsBox) }
        val bpHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(4), 0) }
        bpHead.addView(tv("OUTPUT", 12f, pal.muted, true), LinearLayout.LayoutParams(0, -2, 1f))
        bpHead.addView(button("Clear", "Clear console") { consoleEntries.clear(); consoleBox.removeAllViews(); updateBadges() })
        bpHead.addView(button("✕", "Close panel") { setBottom("none") })
        bottomPanel.addView(bpHead, LinearLayout.LayoutParams(-1, dp(36)))
        bottomPanel.addView(consoleScroll, LinearLayout.LayoutParams(-1, 0, 1f)); bottomPanel.addView(problemsScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(bottomPanel, LinearLayout.LayoutParams(-1, dp(190)))

        // bottom nav
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(pal.panel) }
        val mb = LinkedHashMap<String, TextView>()
        for ((k, label) in listOf("code" to "Code", "split" to "Split", "preview" to "Preview")) {
            val b = button(label, "$label view") { setViewMode(k) }; mb[k] = b; nav.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        modeButtons = mb
        consoleBtn = button("Console", "Console") { setBottom(if (bottomMode == "console") "none" else "console") }
        problemsBtn = button("Problems", "Problems") { setBottom(if (bottomMode == "problems") "none" else "problems") }
        nav.addView(consoleBtn, LinearLayout.LayoutParams(0, dp(44), 1.2f)); nav.addView(problemsBtn, LinearLayout.LayoutParams(0, dp(44), 1.2f))
        main.addView(nav, LinearLayout.LayoutParams(-1, dp(44)))
        statusView = tv("Ready", 11f, pal.muted).apply { setPadding(dp(8), dp(2), dp(8), dp(2)); setSingleLine(); contentDescription = "Status" }
        main.addView(statusView)

        body.addView(main, LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 30) runCatching {
            window.insetsController?.setSystemBarsAppearance(if (pal.dark) 0 else android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS, android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS)
        }
        setViewMode(prefs.getString("view_mode", if (isWide()) "split" else "code") ?: "code")
        setBottom("none")
    }

    private fun fontFace(): Typeface = when (prefs.getString("font", "mono")) {
        "mono_bold" -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        "sans" -> Typeface.SANS_SERIF
        "serif" -> Typeface.SERIF
        else -> Typeface.MONOSPACE
    }

    private fun buildFindBar(): LinearLayout {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.panel2); setPadding(dp(6), dp(4), dp(6), dp(4)) }
        findInput = EditText(this).apply { hint = "Find"; setSingleLine(); setTextColor(pal.text); setHintTextColor(pal.muted); textSize = 14f; contentDescription = "Find input" }
        replInput = EditText(this).apply { hint = "Replace with"; setSingleLine(); setTextColor(pal.text); setHintTextColor(pal.muted); textSize = 14f; contentDescription = "Replace input" }
        findCase = CheckBox(this).apply { text = "Aa"; setTextColor(pal.text); contentDescription = "Match case" }
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        r1.addView(findInput, LinearLayout.LayoutParams(0, -2, 1f)); r1.addView(findCase)
        r1.addView(button("▲", "Find previous") { if (!editor.find(findInput.text.toString(), false, findCase.isChecked)) toast("Not found") })
        r1.addView(button("▼", "Find next") { if (!editor.find(findInput.text.toString(), true, findCase.isChecked)) toast("Not found") })
        r1.addView(button("✕", "Close find") { findBar.visibility = View.GONE })
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        r2.addView(replInput, LinearLayout.LayoutParams(0, -2, 1f))
        r2.addView(button("Replace", "Replace") { editor.replaceCurrent(findInput.text.toString(), replInput.text.toString(), findCase.isChecked) })
        r2.addView(button("All", "Replace all") { toast("${editor.replaceAll(findInput.text.toString(), replInput.text.toString(), findCase.isChecked)} replaced") })
        bar.addView(r1); bar.addView(r2)
        return bar
    }

    private fun toggleFind() {
        findBar.visibility = if (findBar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        if (findBar.visibility == View.VISIBLE) {
            val sel = editor.text.substring(editor.selectionStart.coerceAtLeast(0), editor.selectionEnd.coerceAtLeast(0))
            if (sel.isNotEmpty() && !sel.contains('\n')) findInput.setText(sel)
            findInput.requestFocus()
        }
    }

    private fun toggleExplorer() {
        explorerPanel.visibility = if (explorerPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun setViewMode(m: String) {
        viewMode = m; prefs.edit().putString("view_mode", m).apply()
        editorFrame.visibility = if (m == "preview") View.GONE else View.VISIBLE
        previewFrame.visibility = if (m == "code") View.GONE else View.VISIBLE
        for ((k, b) in modeButtons) b.setTextColor(if (k == m) pal.accent else pal.text)
        for ((k, b) in modeButtons) b.setTypeface(null, if (k == m) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun setBottom(m: String) {
        bottomMode = m
        bottomPanel.visibility = if (m == "none") View.GONE else View.VISIBLE
        consoleScroll.visibility = if (m == "console") View.VISIBLE else View.GONE
        problemsScroll.visibility = if (m == "problems") View.VISIBLE else View.GONE
        consoleBtn.setTextColor(if (m == "console") pal.accent else pal.text); problemsBtn.setTextColor(if (m == "problems") pal.accent else pal.text)
    }

    private fun updateBadges() {
        val ce = consoleEntries.count { it.level == "ERROR" }
        consoleBtn.text = if (ce > 0) "Console ($ce)" else "Console"
        problemsBtn.text = if (staticProblems.isNotEmpty()) "Problems (${staticProblems.size})" else "Problems"
        problemsBtn.contentDescription = "Problems"; consoleBtn.contentDescription = "Console"
    }

    private fun setStatus(s: String) { statusView.text = s }

    // ---------- dashboard ----------
    private fun buildDashboard(): ScrollView {
        val sv = ScrollView(this).apply { setBackgroundColor(pal.bg) }
        sv.tag = "dashboard"
        return sv
    }

    private fun refreshDashboard() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(24), dp(20), dp(24)) }
        box.addView(tv("LIA HTML Studio", 24f, pal.text, true))
        box.addView(tv("HTML · CSS · JavaScript IDE with live preview and LIA AI control", 13f, pal.muted).apply { setPadding(0, dp(4), 0, dp(16)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("New project", "New project", pal.accent, Color.WHITE) { newProjectDialog() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        row.addView(button("Import ZIP", "Import ZIP", pal.panel2) { importZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        row.addView(button("Import folder", "Import folder", pal.panel2) { importTree.launch(null) }, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(row)
        project?.let { p ->
            box.addView(tv("Open project: $p", 14f, pal.text, true).apply { setPadding(0, dp(20), 0, dp(6)) })
            val files = store.tree(p).filter { !it.isDir && ProjectStore.isText(it.path) }.take(8)
            for (f in files) box.addView(button(f.path, "Open file ${f.path}", pal.panel2) { openFile(f.path) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
        }
        box.addView(tv("Recent projects", 14f, pal.text, true).apply { setPadding(0, dp(20), 0, dp(6)) })
        val projects = store.listProjects()
        if (projects.isEmpty()) box.addView(tv("No projects yet.", 13f, pal.muted))
        for (p in projects.take(12)) box.addView(button(p, "Open project $p", pal.panel2) { openProject(p) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
        dashboard.removeAllViews(); dashboard.addView(box)
        dashboard.visibility = if (cur == null) View.VISIBLE else View.GONE
    }

    // ---------- session ----------
    private fun restoreSession() {
        val last = prefs.getString("last_project", null)
        if (last != null && store.exists(last)) {
            project = last
            val open = prefs.getString("open_tabs", "")!!.split("\n").filter { it.isNotEmpty() && store.fileExists(last, it) }
            open.forEach { tabs.add(Tab(it)) }
            buildExplorer(); updateTitle()
            val c = prefs.getString("current_tab", "")!!
            val t = tabs.firstOrNull { it.path == c } ?: tabs.lastOrNull()
            if (t != null) switchTo(t) else { renderTabs(); refreshDashboard() }
        } else if (store.listProjects().isEmpty()) {
            val n = store.createProject("My First Project", "html"); prefs.edit().putBoolean("trusted_$n", true).apply()
            openProject(n); openFile("index.html")
        } else { buildExplorer(); renderTabs(); refreshDashboard(); updateTitle() }
    }

    private fun persistSession() {
        val p = project ?: return
        prefs.edit().putString("last_project", p).putString("open_tabs", tabs.joinToString("\n") { it.path }).putString("current_tab", cur?.path ?: "").apply()
    }

    // ---------- projects ----------
    override fun openProject(name: String) {
        if (!store.exists(name)) { toast("Project not found"); return }
        saveCurrentIfDirty()
        project = name; tabs.clear(); cur = null; expanded.clear()
        consoleEntries.clear(); consoleBox.removeAllViews()
        persistSession(); prefs.edit().putString("last_project", name).apply()
        buildExplorer(); renderTabs(); updateTitle(); refreshDashboard()
        editor.load("", "text"); editor.isEnabled = false
        val entry = if (store.fileExists(name, "index.html")) "index.html" else store.tree(name).firstOrNull { !it.isDir && ProjectStore.isText(it.path) }?.path
        if (entry != null) openFile(entry)
        setStatus("Opened project $name")
    }

    private fun newProjectDialog() {
        val names = Templates.names.toTypedArray()
        var chosen = 0
        val et = EditText(this).apply { hint = "Project name"; setSingleLine(); setText("My Project") }
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("HTML + CSS + JS starter", "Canvas game starter", "Blank HTML")); onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { chosen = pos }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        } }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(et); addView(sp) }
        AlertDialog.Builder(this).setTitle("New project").setView(wrap(box)).setPositiveButton("Create") { _, _ ->
            try {
                val n = store.createProject(store.uniqueName(et.text.toString()), names[chosen])
                prefs.edit().putBoolean("trusted_$n", true).apply(); openProject(n)
            } catch (e: Exception) { err(e) }
        }.setNegativeButton("Cancel", null).show()
    }

    private fun openProjectDialog() {
        val list = store.listProjects()
        if (list.isEmpty()) { toast("No projects"); return }
        AlertDialog.Builder(this).setTitle("Open project").setItems(list.toTypedArray()) { _, i -> openProject(list[i]) }
            .setNeutralButton("Delete…") { _, _ -> deleteProjectDialog(list) }.show()
    }

    private fun deleteProjectDialog(list: List<String>) {
        AlertDialog.Builder(this).setTitle("Delete which project?").setItems(list.toTypedArray()) { _, i ->
            AlertDialog.Builder(this).setTitle("Delete '${list[i]}'?").setMessage("A backup ZIP is made first (Menu → Restore backup).")
                .setPositiveButton("Delete") { _, _ ->
                    runCatching { store.backup(list[i]); store.deleteProject(list[i]) }.onFailure { err(it) }
                    if (project == list[i]) { project = null; tabs.clear(); cur = null; buildExplorer(); renderTabs(); updateTitle(); editor.load("", "text"); refreshDashboard() }
                }.setNegativeButton("Cancel", null).show()
        }.show()
    }

    private fun updateTitle() { titleView.text = (project ?: "No project") + (cur?.let { " › " + it.path } ?: "") }

    // ---------- explorer ----------
    private fun buildExplorer() {
        explorerList.removeAllViews()
        val p = project ?: return
        val tree = runCatching { store.tree(p) }.getOrDefault(emptyList())
        for (e in tree) {
            val parts = e.path.split("/")
            var visible = true
            for (i in 1 until parts.size) if (!expanded.contains(parts.take(i).joinToString("/"))) { visible = false; break }
            if (!visible) continue
            val depth = parts.size - 1
            val icon = if (e.isDir) (if (expanded.contains(e.path)) "▾ 📁 " else "▸ 📁 ") else "     " + fileIcon(e.path)
            val row = tv(icon + parts.last(), 14f, if (cur?.path == e.path) pal.accent else pal.text).apply {
                setPadding(dp(8 + depth * 14), dp(9), dp(8), dp(9)); setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END
                contentDescription = (if (e.isDir) "Folder: " else "File: ") + e.path
                isClickable = true
                setOnClickListener { if (e.isDir) { if (!expanded.add(e.path)) expanded.remove(e.path); buildExplorer() } else { openFile(e.path); if (!isWide()) explorerPanel.visibility = View.GONE } }
                setOnLongClickListener { fileActions(e); true }
            }
            explorerList.addView(row)
        }
        if (tree.isEmpty()) explorerList.addView(tv("Empty project", 13f, pal.muted).apply { setPadding(dp(12), dp(12), 0, 0) })
    }

    private fun fileIcon(path: String) = when (ProjectStore.ext(path)) {
        "html", "htm", "svg" -> "🌐 "; "css" -> "🎨 "; "js", "mjs" -> "📜 "; "json", "webmanifest" -> "🧾 "
        "png", "jpg", "jpeg", "gif", "webp", "svg", "ico" -> "🖼 "; else -> "📄 "
    }

    private fun parentOf(path: String) = if (path.contains('/')) path.substringBeforeLast('/') else ""

    private fun fileActions(e: FileEntry) {
        val dir = if (e.isDir) e.path else parentOf(e.path)
        val items = arrayOf("New file here", "New folder here", "Import files here…", "Rename", "Copy to…", "Move to…", "Delete")
        AlertDialog.Builder(this).setTitle(e.path).setItems(items) { _, i ->
            val p = project ?: return@setItems
            when (i) {
                0 -> newFileDialog(dir)
                1 -> newFolderDialog(dir)
                2 -> { pickerDest = dir; importFiles.launch(arrayOf("*/*")) }
                3 -> prompt("Rename", "New path", e.path) { n -> fileOp { saveCurrentIfDirty(); store.rename(p, e.path, n); retargetTabs(e.path, n) } }
                4 -> prompt("Copy to", "Destination path", e.path + "_copy") { n -> fileOp { store.copy(p, e.path, n) } }
                5 -> prompt("Move to", "Destination path", e.path) { n -> fileOp { saveCurrentIfDirty(); store.move(p, e.path, n); retargetTabs(e.path, n) } }
                6 -> AlertDialog.Builder(this).setTitle("Delete ${e.path}?").setMessage(if (e.isDir) "The folder and everything inside it will be deleted." else "This file will be deleted.")
                    .setPositiveButton("Delete") { _, _ -> fileOp {
                        saveCurrentIfDirty()
                        if (!e.isDir && ProjectStore.isText(e.path)) store.recordChange(p, e.path, store.read(p, e.path), "UI_DELETE")
                        store.delete(p, e.path); closeTabsUnder(e.path)
                    } }.setNegativeButton("Cancel", null).show()
            }
        }.show()
    }

    private fun fileOp(block: () -> Unit) { try { block(); buildExplorer(); renderTabs() } catch (e: Exception) { err(e) } }

    private fun retargetTabs(old: String, new: String) {
        val wasCur = cur?.path
        val ts = tabs.toList(); tabs.clear()
        for (t in ts) {
            val np = if (t.path == old) new else if (t.path.startsWith("$old/")) new + t.path.removePrefix(old) else t.path
            tabs.add(Tab(np).also { it.cursor = t.cursor })
        }
        cur = tabs.firstOrNull { it.path == (wasCur?.let { w -> if (w == old) new else if (w.startsWith("$old/")) new + w.removePrefix(old) else w }) }
        updateTitle()
    }

    private fun closeTabsUnder(path: String) {
        val closing = tabs.filter { it.path == path || it.path.startsWith("$path/") }
        val wasCur = closing.contains(cur)
        tabs.removeAll(closing.toSet())
        if (wasCur) { cur = null; val n = tabs.lastOrNull(); if (n != null) switchTo(n) else { editor.load("", "text"); editor.isEnabled = false; refreshDashboard() } }
        updateTitle()
    }

    private fun newFileDialog(dir: String) {
        val p = project ?: return toast("Open a project first")
        prompt("New file", "name.ext", if (dir.isEmpty()) "" else "$dir/") { n ->
            if (n.isEmpty()) return@prompt
            try { if (store.fileExists(p, n)) throw StoreException("EXISTS", "File exists"); store.write(p, n, ""); expandParents(n); buildExplorer(); openFile(n) } catch (e: Exception) { err(e) }
        }
    }

    private fun newFolderDialog(dir: String) {
        val p = project ?: return toast("Open a project first")
        prompt("New folder", "folder name", if (dir.isEmpty()) "" else "$dir/") { n ->
            if (n.isEmpty()) return@prompt
            try { store.mkdir(p, n); expandParents("$n/x"); buildExplorer() } catch (e: Exception) { err(e) }
        }
    }

    private fun expandParents(path: String) { val parts = path.split("/"); for (i in 1 until parts.size) expanded.add(parts.take(i).joinToString("/")) }

    // ---------- tabs ----------
    private fun renderTabs() {
        tabsBar.removeAllViews()
        for (t in tabs) {
            val active = t === cur
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(if (active) pal.bg else pal.panel2); setPadding(dp(10), 0, dp(2), 0) }
            val name = tv((if (t.dirty) "● " else "") + t.path.substringAfterLast('/'), 13f, if (active) pal.text else pal.muted).apply { contentDescription = "Tab: ${t.path}"; isClickable = true; setOnClickListener { switchTo(t) } }
            row.addView(name, LinearLayout.LayoutParams(-2, dp(40)).apply { gravity = Gravity.CENTER_VERTICAL })
            (name.layoutParams as LinearLayout.LayoutParams).let { name.gravity = Gravity.CENTER_VERTICAL }
            row.addView(button("✕", "Close tab ${t.path}") { closeTab(t) }.apply { minWidth = dp(32) })
            tabsBar.addView(row)
        }
    }

    private fun closeTab(t: Tab) {
        if (t === cur) saveCurrentIfDirty()
        val idx = tabs.indexOf(t); tabs.remove(t)
        if (t === cur) {
            cur = null
            val n = tabs.getOrNull((idx - 1).coerceAtLeast(0))
            if (n != null) switchTo(n) else { editor.load("", "text"); editor.isEnabled = false; editor.markErrors(emptySet()); refreshDashboard(); updateTitle() }
        }
        renderTabs(); persistSession()
    }

    private fun draftFile(p: String, path: String) = File(File(filesDir, "drafts/$p").apply { mkdirs() }, path.replace('/', '%') + ".draft")

    fun openFile(path: String, line: Int = 0) {
        val p = project ?: return
        if (ProjectStore.isImage(path)) { showImage(p, path); return }
        if (!ProjectStore.isText(path)) { toast("Binary file – cannot edit"); return }
        saveCurrentIfDirty()
        val t = tabs.firstOrNull { it.path == path } ?: Tab(path).also { tabs.add(it) }
        switchTo(t)
        if (line > 0) editor.gotoLine(line)
    }

    private fun switchTo(t: Tab) {
        val p = project ?: return
        if (cur != null && cur !== t) { cur!!.cursor = editor.selectionStart.coerceAtLeast(0); saveCurrentIfDirty() }
        cur = t
        try {
            var text = store.read(p, t.path)
            val d = draftFile(p, t.path)
            if (d.isFile && d.readText() != text && d.lastModified() >= File(store.projectDir(p), t.path).lastModified()) {
                val draft = d.readText()
                AlertDialog.Builder(this).setTitle("Recover unsaved changes?").setMessage("${t.path} has unsaved changes from before the app closed.")
                    .setPositiveButton("Recover") { _, _ -> editor.load(draft, Highlighter.langOf(t.path)); t.dirty = true; renderTabs(); scheduleAutosave(); runValidation() }
                    .setNegativeButton("Discard") { _, _ -> d.delete() }.show()
            }
            editor.isEnabled = true
            editor.load(text, Highlighter.langOf(t.path))
            editor.setSelection(t.cursor.coerceIn(0, editor.length()))
            text = ""
        } catch (e: Exception) { toast("Cannot open ${t.path}: ${e.message}"); tabs.remove(t); cur = null; renderTabs(); return }
        dashboard.visibility = View.GONE
        renderTabs(); updateTitle(); buildExplorer(); runValidation(); persistSession()
    }

    private fun showImage(p: String, path: String) {
        val f = store.resolve(p, path)
        val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
        val bmp: Bitmap? = runCatching { BitmapFactory.decodeFile(f.path, opts) }.getOrNull()
        val iv = ImageView(this).apply { setImageBitmap(bmp); adjustViewBounds = true; setBackgroundColor(Color.DKGRAY) }
        AlertDialog.Builder(this).setTitle("$path (${f.length() / 1024} KB)").setView(iv).setPositiveButton("Close", null)
            .setNeutralButton("Insert <img>") { _, _ -> editor.text.replace(editor.selectionStart.coerceAtLeast(0), editor.selectionEnd.coerceAtLeast(0), "<img src=\"$path\" alt=\"\">") }.show()
    }

    // ---------- editing, saving, validation ----------
    private val autosave = Runnable { saveCurrentIfDirty() }
    private val draftWrite = Runnable { writeDraft() }
    private val validate = Runnable { runValidation() }

    private fun onEditorChanged() {
        val t = cur ?: return
        if (!t.dirty) { t.dirty = true; renderTabs() }
        ui.removeCallbacks(draftWrite); ui.postDelayed(draftWrite, 500)
        ui.removeCallbacks(validate); ui.postDelayed(validate, 900)
        scheduleAutosave()
    }

    private fun scheduleAutosave() { ui.removeCallbacks(autosave); if (prefs.getBoolean("autosave", true)) ui.postDelayed(autosave, 1500) }

    private fun writeDraft() {
        val p = project ?: return; val t = cur ?: return
        if (!t.dirty || editor.length() > 3_000_000) return
        runCatching { draftFile(p, t.path).writeText(editor.text.toString()) }
    }

    fun saveCurrentIfDirty() {
        val p = project ?: return; val t = cur ?: return
        if (!t.dirty) return
        try {
            store.write(p, t.path, editor.text.toString())
            t.dirty = false; draftFile(p, t.path).delete()
            renderTabs(); setStatus("Saved ${t.path}")
            onSavedLiveReload(t.path)
        } catch (e: Exception) { setStatus("SAVE FAILED: ${e.message}"); toast("Save failed: ${e.message}") }
    }

    private fun runValidation() {
        val t = cur ?: run { staticProblems = emptyList(); renderProblems(); return }
        val path = t.path; val text = editor.text.toString()
        bg.execute {
            val probs = runCatching { Validator.validate(path, text) }.getOrDefault(emptyList())
            ui.post {
                if (cur?.path != path) return@post
                staticProblems = probs; staticLines = probs.map { it.line }.toSet()
                editor.markErrors(staticLines + runtimeLines); renderProblems(); updateBadges()
            }
        }
    }

    private fun renderProblems() {
        problemsBox.removeAllViews()
        if (staticProblems.isEmpty()) problemsBox.addView(tv("No problems found in ${cur?.path ?: "file"} (static check: brackets, tags, JSON).", 12f, pal.muted).apply { setPadding(dp(10), dp(8), dp(10), 0) })
        for (pr in staticProblems) {
            val (en, hi) = Explain.explain(pr.message)
            problemsBox.addView(tv("✖ Line ${pr.line}:${pr.column}  ${pr.message}\nEN: $en\nHI: $hi", 12f, pal.text).apply {
                setPadding(dp(10), dp(8), dp(10), dp(8)); contentDescription = "Problem line ${pr.line}: ${pr.message}"
                isClickable = true; setOnClickListener { editor.gotoLine(pr.line) }
            })
        }
    }

    private fun formatCurrent() {
        val t = cur ?: return
        val old = editor.text.toString()
        val nu = Formatter.format(t.path, old)
        if (nu == old) { toast("Already formatted"); return }
        editor.text.replace(0, editor.text.length, nu); toast("Formatted (undo available)")
    }

    private fun gotoLineDialog() { prompt("Go to line", "line number") { n -> n.toIntOrNull()?.let { editor.gotoLine(it) } } }

    // ---------- IdeController (LIA) ----------
    override fun editorSnapshot(): JSONObject? {
        val t = cur ?: return null; val p = project ?: return null
        return JSONObject().put("project", p).put("path", t.path).put("text", editor.text.toString())
            .put("sel_start", editor.selectionStart.coerceAtLeast(0)).put("sel_end", editor.selectionEnd.coerceAtLeast(0))
            .put("selected_text", editor.text.substring(editor.selectionStart.coerceAtLeast(0), editor.selectionEnd.coerceAtLeast(0)))
            .put("cursor_line", editor.currentLine()).put("dirty", t.dirty)
            .put("open_tabs", JSONArray(tabs.map { it.path }))
    }

    override fun insertAtCursor(text: String): Boolean {
        if (cur == null || !editor.isEnabled) return false
        val s = editor.selectionStart.coerceAtLeast(0); val e = editor.selectionEnd.coerceAtLeast(s)
        editor.text.replace(s, e, text); editor.setSelection((s + text.length).coerceAtMost(editor.length())); return true
    }

    override fun replaceSelection(text: String): Boolean {
        if (cur == null || !editor.isEnabled || editor.selectionStart == editor.selectionEnd) return false
        return insertAtCursor(text)
    }

    override fun flush(project: String, path: String?) {
        if (project != this.project) return
        if (path == null || path == cur?.path) saveCurrentIfDirty()
    }

    override fun reload(project: String, path: String?) {
        if (project != this.project) return
        buildExplorer()
        val gone = tabs.filter { !store.fileExists(project, it.path) }
        for (g in gone) { val wasCur = g === cur; tabs.remove(g); if (wasCur) { cur = null; val n = tabs.lastOrNull(); if (n != null) switchTo(n) else { editor.load("", "text"); editor.isEnabled = false; refreshDashboard() } } }
        val t = cur
        if (t != null && (path == null || path == t.path) && store.fileExists(project, t.path)) {
            val disk = store.read(project, t.path)
            if (disk != editor.text.toString()) { val c = editor.selectionStart; editor.load(disk, Highlighter.langOf(t.path)); editor.setSelection(c.coerceIn(0, editor.length())); t.dirty = false; draftFile(project, t.path).delete(); runValidation() }
        }
        if (path != null && gone.isEmpty() && tabs.none { it.path == path } && store.fileExists(project, path) && ProjectStore.isText(path) && tabs.isEmpty()) openFile(path)
        renderTabs(); updateTitle(); refreshDashboard()
    }

    override fun console(): List<ConsoleEntry> = consoleEntries.toList()

    override fun status(): JSONObject = JSONObject().put("project", project ?: JSONObject.NULL).put("current_file", cur?.path ?: JSONObject.NULL)
        .put("open_tabs", JSONArray(tabs.map { it.path })).put("dirty_tabs", JSONArray(tabs.filter { it.dirty }.map { it.path }))
        .put("preview_running", runningEntry != null).put("preview_entry", runningEntry ?: JSONObject.NULL)
        .put("console_error_count", consoleEntries.count { it.level == "ERROR" }).put("view_mode", viewMode)

    override fun notifyApprovals() { ui.post { showNextApproval() } }

    private fun showNextApproval() {
        if (isFinishing || approvalDialog?.isShowing == true) return
        val a = LiaApi.pendingApprovals().firstOrNull() ?: return
        approvalDialog = AlertDialog.Builder(this).setTitle("LIA AI requests approval").setMessage("LIA AI wants to:\n\n${a.description}\n\nThis cannot be done without your approval.")
            .setCancelable(false)
            .setPositiveButton("Allow") { _, _ -> LiaApi.resolveApproval(a.id, true); ui.post { showNextApproval() } }
            .setNegativeButton("Deny") { _, _ -> LiaApi.resolveApproval(a.id, false); ui.post { showNextApproval() } }.show()
    }

    // ---------- preview ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun configurePreview() {
        val s = preview.settings
        s.javaScriptEnabled = true; s.domStorageEnabled = true
        s.allowFileAccess = false; s.allowContentAccess = false
        @Suppress("DEPRECATION") run { s.allowFileAccessFromFileURLs = false; s.allowUniversalAccessFromFileURLs = false }
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.cacheMode = WebSettings.LOAD_NO_CACHE
        s.useWideViewPort = true; s.loadWithOverviewMode = true
        s.setSupportZoom(true); s.builtInZoomControls = true; s.displayZoomControls = false
        assetLoader = WebViewAssetLoader.Builder().setDomain(PREVIEW_HOST).addPathHandler("/project/", WebViewAssetLoader.PathHandler { path -> serveProjectFile(path) }).build()
        preview.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                val lvl = when (m.messageLevel()) { ConsoleMessage.MessageLevel.ERROR -> "ERROR"; ConsoleMessage.MessageLevel.WARNING -> "WARN"; else -> "LOG" }
                addConsole(ConsoleEntry(lvl, m.message(), cleanSource(m.sourceId()), m.lineNumber(), System.currentTimeMillis())); return true
            }
        }
        preview.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == PREVIEW_HOST) return false
                addConsole(ConsoleEntry("WARN", "Navigation to external URL blocked: ${request.url}", "", 0, System.currentTimeMillis())); return true
            }
            override fun onPageFinished(view: WebView, url: String) {
                if (url == "about:blank") return
                if (desktopMode) view.evaluateJavascript("(function(){var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}m.setAttribute('content','width=1280');})()", null)
                val tok = runToken
                ui.postDelayed({ if (tok == runToken) finishRun(true) }, 1200)
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.url.host == PREVIEW_HOST || request.isForMainFrame)
                    addConsole(ConsoleEntry("ERROR", "Failed to load resource: ${request.url.path} (${error.description})", request.url.path ?: "", 0, System.currentTimeMillis()))
            }
            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, resp: WebResourceResponse) {
                addConsole(ConsoleEntry("ERROR", "Failed to load resource: ${request.url.path} (HTTP ${resp.statusCode} – file not found in project)", request.url.path ?: "", 0, System.currentTimeMillis()))
            }
        }
        preview.loadUrl("about:blank")
    }

    private fun cleanSource(s: String?): String = (s ?: "").removePrefix("https://$PREVIEW_HOST/project/")

    private fun serveProjectFile(path: String): WebResourceResponse {
        val p = project
        fun notFound() = WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), ByteArrayInputStream("404 ${path}".toByteArray()))
        if (p == null) return notFound()
        val f = try { store.resolve(p, Uri.decode(path)) } catch (e: StoreException) { return notFound() }
        if (!f.isFile) return notFound()
        val ext = ProjectStore.ext(f.name)
        val mime = when (ext) {
            "html", "htm" -> "text/html"; "js", "mjs" -> "application/javascript"; "css" -> "text/css"; "json", "webmanifest" -> "application/json"
            "svg" -> "image/svg+xml"; "wasm" -> "application/wasm"; "txt", "md" -> "text/plain"; "xml" -> "text/xml"
            else -> android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
        val enc = if (mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") || mime.contains("xml")) "UTF-8" else null
        return WebResourceResponse(mime, enc, 200, "OK", mapOf("Cache-Control" to "no-store"), FileInputStream(f))
    }

    private fun addConsole(e: ConsoleEntry) {
        consoleEntries.add(e)
        if (consoleEntries.size > 500) { consoleEntries.removeAt(0); if (consoleBox.childCount > 0) consoleBox.removeViewAt(0) }
        val color = when (e.level) { "ERROR" -> if (pal.dark) 0xFFFF7B72.toInt() else 0xFFCF222E.toInt(); "WARN" -> if (pal.dark) 0xFFE3B341.toInt() else 0xFF9A6700.toInt(); else -> pal.text }
        val loc = if (e.source.isNotEmpty()) "  (${e.source}:${e.line})" else ""
        val row = tv("${if (e.level == "ERROR") "✖ " else if (e.level == "WARN") "⚠ " else "› "}${e.message}$loc", 12f, color).apply {
            typeface = Typeface.MONOSPACE; setPadding(dp(10), dp(4), dp(10), dp(4)); contentDescription = "${e.level}: ${e.message}$loc"
            if (e.level == "ERROR") {
                setOnClickListener {
                    val (en, hi) = Explain.explain(e.message)
                    AlertDialog.Builder(this@MainActivity).setTitle("Error explained").setMessage("${e.message}\n\nEnglish:\n$en\n\nहिन्दी / Hinglish:\n$hi")
                        .setPositiveButton("OK", null).setNeutralButton("Go to line") { _, _ -> if (store.fileExists(project ?: "", e.source)) openFile(e.source, e.line) }.show()
                }
            }
        }
        consoleBox.addView(row)
        consoleScroll.post { consoleScroll.fullScroll(View.FOCUS_DOWN) }
        if (e.level == "ERROR") { updateBadges(); if (bottomMode == "none") setStatus("JS/preview error: ${e.message}") }
    }

    private fun pickEntry(): String? {
        val p = project ?: return null
        val c = cur?.path
        if (c != null && ProjectStore.ext(c) in setOf("html", "htm")) return c
        if (store.fileExists(p, "index.html")) return "index.html"
        return store.tree(p).firstOrNull { !it.isDir && ProjectStore.ext(it.path) in setOf("html", "htm") }?.path
    }

    private fun runFromUi() {
        val p = project ?: return toast("Open a project first")
        if (!prefs.getBoolean("trusted_$p", false)) {
            AlertDialog.Builder(this).setTitle("Run untrusted code?").setMessage("'$p' was imported. Its JavaScript will run in the preview with network access. Only run projects you trust.")
                .setPositiveButton("Trust & run") { _, _ -> prefs.edit().putBoolean("trusted_$p", true).apply(); runFromUi() }.setNegativeButton("Cancel", null).show()
            return
        }
        if (viewMode == "code") setViewMode(if (isWide()) "split" else "preview")
        runProject(null, null) { r -> val n = r.optInt("error_count"); setStatus(if (r.optBoolean("loaded")) "Run finished: $n error(s)" else "Run failed to load") ; if (n > 0 && bottomMode == "none") setBottom("console") }
    }

    override fun runProject(entry: String?, mode: String?, done: (JSONObject) -> Unit) {
        val p = project ?: return done(JSONObject().put("loaded", false).put("error_count", 1).put("errors", JSONArray().put("No project open")))
        saveCurrentIfDirty()
        val e = entry ?: pickEntry()
        if (e == null || !store.fileExists(p, e)) { done(JSONObject().put("loaded", false).put("error_count", 1).put("errors", JSONArray().put("No HTML entry file found" + (entry?.let { " ($it)" } ?: "")))); return }
        if (mode != null) setDesktop(mode == "desktop", reload = false)
        pendingRun?.let { finishRun(false) }
        runToken++; pendingRun = done; runningEntry = e
        consoleEntries.clear(); consoleBox.removeAllViews(); runtimeLines = emptySet(); updateBadges()
        loadPreviewFresh(e)
        setStatus("Running $e …")
        val tok = runToken
        ui.postDelayed({ if (tok == runToken && pendingRun != null) finishRun(false) }, 10_000)
    }

    private fun finishRun(loaded: Boolean) {
        val cb = pendingRun ?: return; pendingRun = null
        val errs = consoleEntries.filter { it.level == "ERROR" }
        val arr = JSONArray(); errs.take(50).forEach { arr.put(it.toJson()) }
        val warn = consoleEntries.count { it.level == "WARN" }
        runtimeLines = errs.filter { it.source == cur?.path }.map { it.line }.toSet()
        editor.markErrors(staticLines + runtimeLines); updateBadges()
        cb(JSONObject().put("loaded", loaded).put("entry", runningEntry ?: JSONObject.NULL).put("error_count", errs.size).put("warning_count", warn)
            .put("console_count", consoleEntries.size).put("errors", arr).put("mode", if (desktopMode) "desktop" else "mobile")
            .put("note", if (loaded) "Page loaded; errors captured for ~1.2 s after load. Errors from later timers/events appear in GET_CONSOLE_ERRORS." else "Page did not finish loading in time"))
    }

    private fun loadPreviewFresh(entry: String) {
        // A unique query string forces WebView and intermediary caches to treat each Run as a new document.
        val nonce = System.currentTimeMillis()
        preview.loadUrl("https://$PREVIEW_HOST/project/$entry?__lia_run=$nonce")
    }

    private fun reloadPreviewFresh() {
        val entry = runningEntry ?: return
        loadPreviewFresh(entry)
        setStatus("Preview refreshed")
    }

    override fun stopPreview() { runToken++; pendingRun?.let { finishRun(false) }; runningEntry = null; preview.loadUrl("about:blank"); setStatus("Preview stopped") }

    private fun capturePreviewScreenshot() {
        if (runningEntry == null) { toast("Run a project before taking a screenshot"); return }
        if (previewFrame.visibility != View.VISIBLE || preview.width <= 0 || preview.height <= 0) {
            toast("Open Split or Preview view first")
            return
        }
        runCatching {
            val bitmap = Bitmap.createBitmap(preview.width, preview.height, Bitmap.Config.ARGB_8888)
            preview.draw(Canvas(bitmap))
            val fileName = "LIA_HTML_Studio_${System.currentTimeMillis()}.png"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LIA HTML Studio")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create Gallery image")
                try {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw IllegalStateException("Screenshot encoding failed")
                    } ?: throw IllegalStateException("Could not open Gallery output")
                    values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                } catch (e: Exception) {
                    contentResolver.delete(uri, null, null)
                    throw e
                }
            } else {
                val dir = File(getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES), "LIA HTML Studio")
                if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Could not create screenshot folder")
                File(dir, fileName).outputStream().use { out ->
                    if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw IllegalStateException("Screenshot encoding failed")
                }
            }
            bitmap.recycle()
            toast(if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) "Screenshot saved to Gallery / Pictures / LIA HTML Studio" else "Screenshot saved in app Pictures folder")
        }.onFailure { err(it) }
    }

    private fun setDesktop(on: Boolean, reload: Boolean) {
        desktopMode = on
        val s = preview.settings
        s.userAgentString = if (on) "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36" else null
        if (reload && runningEntry != null) reloadPreviewFresh()
        setStatus(if (on) "Preview: desktop mode (1280px viewport)" else "Preview: mobile mode")
    }

    private fun onSavedLiveReload(path: String) {
        if (!prefs.getBoolean("live_reload", true) || runningEntry == null || previewFrame.visibility != View.VISIBLE) return
        if (ProjectStore.ext(path) == "css") {
            preview.evaluateJavascript("document.querySelectorAll('link[rel=stylesheet]').forEach(function(l){l.href=l.href.split('?')[0]+'?v='+Date.now();})", null)
            setStatus("CSS live-updated")
        } else { consoleEntries.clear(); consoleBox.removeAllViews(); runToken++; reloadPreviewFresh() }
    }

    // ---------- menu ----------
    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        val items = listOf("New project…", "Open project…", "Import ZIP…", "Import folder…", "Export ZIP…", "Backup project", "Restore backup…",
            "Import files / assets…", "Search in project…", "Go to line…", "Format document", "Snippets…", "Color picker…",
            if (desktopMode) "Preview: switch to mobile" else "Preview: switch to desktop (1280px)", "Refresh preview", "Undo last AI change", "LIA activity log", "Settings", "About / limitations", "Capture preview screenshot")
        items.forEachIndexed { i, s -> m.menu.add(0, i, i, s) }
        m.setOnMenuItemClickListener { mi ->
            when (mi.itemId) {
                0 -> newProjectDialog(); 1 -> openProjectDialog()
                2 -> importZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
                3 -> importTree.launch(null)
                4 -> { val p = project; if (p == null) toast("No project") else { saveCurrentIfDirty(); exportZip.launch("$p.zip") } }
                5 -> project?.let { p -> saveCurrentIfDirty(); runCatching { store.backup(p) }.onSuccess { toast("Backup saved: ${it.name}") }.onFailure { err(it) } }
                6 -> restoreDialog()
                7 -> { pickerDest = "assets"; importFiles.launch(arrayOf("*/*")) }
                8 -> searchDialog(); 9 -> gotoLineDialog(); 10 -> formatCurrent(); 11 -> snippetsDialog(); 12 -> colorDialog()
                13 -> setDesktop(!desktopMode, true)
                14 -> { if (runningEntry != null) { consoleEntries.clear(); consoleBox.removeAllViews(); runToken++; reloadPreviewFresh() } else runFromUi() }
                15 -> undoAi(); 16 -> activityDialog(); 17 -> settingsDialog(); 18 -> aboutDialog(); 19 -> capturePreviewScreenshot()
            }
            true
        }
        m.show()
    }

    private fun undoAi() {
        val p = project ?: return
        saveCurrentIfDirty()
        val changes = store.listChanges(p)
        if (changes.isEmpty()) { toast("No recorded AI/tool changes"); return }
        val c = changes.first()
        AlertDialog.Builder(this).setTitle("Undo last change?").setMessage("${c.optString("cause")} on ${c.optString("file")}\nThe file is restored to its content before that change.")
            .setPositiveButton("Undo") { _, _ -> runCatching { store.undoLastChange(p) }.onSuccess { f -> if (f != null) { reload(p, f); toast("Restored $f") } }.onFailure { err(it) } }
            .setNegativeButton("Cancel", null).show()
    }

    private fun activityDialog() {
        val log = LiaApi.activityLog().reversed().joinToString("\n").ifEmpty { "No LIA activity yet." }
        AlertDialog.Builder(this).setTitle("LIA activity").setMessage(log).setPositiveButton("OK", null).show()
    }

    private fun aboutDialog() {
        AlertDialog.Builder(this).setTitle("LIA HTML Studio 2.1").setMessage(
            "HTML/CSS/JavaScript IDE: multi-file projects, tabs, HTML/CSS/JS/JSON syntax highlighting, HTML tag auto-close, bracket matching, auto-indent, undo/redo, find/replace, " +
            "ZIP/folder import, ZIP export, backups, live WebView preview, console + bilingual error explanations (EN/HI), LIA command API, approvals and AI change history.\n\n" +
            "Not available yet: code folding, multi-cursor, Git integration and a full JavaScript parser/linter before preview. JavaScript runtime errors appear in the Preview Console.").setPositiveButton("OK", null).show()
    }

    // ---------- SAF handlers ----------
    private fun displayName(uri: Uri): String? = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }

    private fun doImportZip(uri: Uri) {
        val base = (displayName(uri) ?: "Imported").removeSuffix(".zip")
        setStatus("Importing ZIP…")
        bg.execute {
            try {
                val n = contentResolver.openInputStream(uri)!!.use { store.importZip(it, base) }
                prefs.edit().putBoolean("trusted_$n", false).apply()
                ui.post { toast("Imported as '$n' (untrusted until you accept the run warning)"); openProject(n) }
            } catch (e: Exception) { ui.post { err(e); setStatus("Import failed") } }
        }
    }

    private fun doExportZip(uri: Uri) {
        val p = project ?: return
        bg.execute {
            try { contentResolver.openOutputStream(uri)!!.use { store.exportZip(p, it) }; ui.post { toast("Exported $p") } }
            catch (e: Exception) { ui.post { err(e) } }
        }
    }

    private fun doImportTree(uri: Uri) {
        val root = DocumentFile.fromTreeUri(this, uri) ?: return toast("Cannot read folder")
        val name = store.uniqueName(root.name ?: "Imported folder")
        setStatus("Importing folder…")
        bg.execute {
            try {
                store.createProject(name, "blank", mapOf(".lia-keep" to ""))
                var count = 0; var total = 0L
                fun walk(d: DocumentFile, rel: String) {
                    for (c in d.listFiles()) {
                        val n = c.name ?: continue
                        if (n.startsWith(".git")) continue
                        val r = if (rel.isEmpty()) n else "$rel/$n"
                        if (c.isDirectory) walk(c, r) else {
                            if (++count > ProjectStore.MAX_ZIP_ENTRIES || total > ProjectStore.MAX_ZIP_TOTAL) throw StoreException("TOO_BIG", "Folder too large to import")
                            total += c.length()
                            contentResolver.openInputStream(c.uri)?.use { store.writeBytes(name, r, it) }
                        }
                    }
                }
                walk(root, ""); runCatching { store.delete(name, ".lia-keep") }
                prefs.edit().putBoolean("trusted_$name", false).apply()
                ui.post { toast("Imported $count files as '$name'"); openProject(name) }
            } catch (e: Exception) { runCatching { store.deleteProject(name) }; ui.post { err(e) } }
        }
    }

    private fun doImportFiles(uris: List<Uri>) {
        val p = project ?: return toast("Open a project first")
        bg.execute {
            var n = 0
            try {
                for (u in uris) {
                    val nm = (displayName(u) ?: "file_${System.nanoTime()}").replace('/', '_').replace('\\', '_')
                    val rel = if (pickerDest.isEmpty()) nm else "$pickerDest/$nm"
                    contentResolver.openInputStream(u)?.use { store.writeBytes(p, rel, it) }; n++
                }
                ui.post { toast("Imported $n file(s)"); expandParents("$pickerDest/x"); buildExplorer() }
            } catch (e: Exception) { ui.post { err(e) } }
        }
    }

    private fun restoreDialog() {
        val list = store.listBackups()
        if (list.isEmpty()) { toast("No backups"); return }
        val labels = list.map { it.name.substringBefore("__") + "  " + java.text.SimpleDateFormat("dd MMM HH:mm", java.util.Locale.US).format(java.util.Date(it.lastModified())) }
        AlertDialog.Builder(this).setTitle("Restore backup (as a new project)").setItems(labels.toTypedArray()) { _, i ->
            bg.execute { try { val n = store.restoreBackup(list[i]); prefs.edit().putBoolean("trusted_$n", true).apply(); ui.post { openProject(n) } } catch (e: Exception) { ui.post { err(e) } } }
        }.show()
    }

    // ---------- search, snippets, color ----------
    private fun searchDialog() {
        val p = project ?: return toast("Open a project first")
        val q = EditText(this).apply { hint = "Search all files"; setSingleLine() }
        val list = ListView(this)
        val hits = ArrayList<SearchHit>()
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ArrayList())
        list.adapter = adapter
        val go = button("Search", "Run project search", pal.accent, Color.WHITE) {
            saveCurrentIfDirty(); hits.clear(); adapter.clear()
            val query = q.text.toString()
            bg.execute { val r = store.search(p, query, false); ui.post { hits.addAll(r); adapter.addAll(r.map { "${it.path}:${it.line}  ${it.text}" }); if (r.isEmpty()) toast("No matches") } }
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(q); addView(go); addView(list, LinearLayout.LayoutParams(-1, dp(320))) }
        val dlg = AlertDialog.Builder(this).setTitle("Search in project").setView(wrap(box)).setNegativeButton("Close", null).create()
        list.setOnItemClickListener { _, _, i, _ -> openFile(hits[i].path, hits[i].line); dlg.dismiss() }
        dlg.show()
    }

    private fun snippetsDialog() {
        val sn = Templates.snippets
        AlertDialog.Builder(this).setTitle("Insert snippet").setItems(sn.map { it.first }.toTypedArray()) { _, i -> if (!insertAtCursor(sn[i].second)) toast("Open a file first") }.show()
    }

    private fun colorDialog() {
        var r = 40; var g = 168; var b = 121
        val sw = View(this)
        val hex = tv("", 16f, pal.text, true)
        fun upd() { val c = Color.rgb(r, g, b); sw.setBackgroundColor(c); hex.text = "#%02X%02X%02X".format(r, g, b) }
        fun bar(label: String, init: Int, set: (Int) -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(tv(label, 14f, pal.text), LinearLayout.LayoutParams(dp(24), -2))
            addView(SeekBar(this@MainActivity).apply { max = 255; progress = init; contentDescription = "Color $label"
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { set(v); upd() }
                    override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
                }) }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
            addView(sw, LinearLayout.LayoutParams(-1, dp(56))); addView(hex)
            addView(bar("R", r) { r = it }); addView(bar("G", g) { g = it }); addView(bar("B", b) { b = it }) }
        upd()
        AlertDialog.Builder(this).setTitle("Color picker").setView(wrap(box)).setPositiveButton("Insert") { _, _ -> if (!insertAtCursor(hex.text.toString())) toast("Open a file first") }
            .setNeutralButton("Copy") { _, _ -> (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("color", hex.text)) }
            .setNegativeButton("Close", null).show()
    }

    // ---------- settings ----------
    private fun settingsDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, 0) }
        fun check(label: String, key: String, def: Boolean) = CheckBox(this).apply { text = label; isChecked = prefs.getBoolean(key, def); setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply(); if (key == "auto_close") editor.autoClose = v } }
        box.addView(check("Auto-save while typing", "autosave", true))
        box.addView(check("Live reload preview on save", "live_reload", true))
        box.addView(check("Auto-close brackets and quotes", "auto_close", true))
        box.addView(tv("Theme", 13f, pal.muted).apply { setPadding(0, dp(10), 0, 0) })
        val th = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Dark", "Light")); setSelection(if (pal.dark) 0 else 1) }
        box.addView(th)
        box.addView(tv("Editor font", 13f, pal.muted).apply { setPadding(0, dp(10), 0, 0) })
        val fonts = listOf("mono" to "Monospace", "mono_bold" to "Monospace bold", "sans" to "Sans-serif", "serif" to "Serif")
        val fs = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, fonts.map { it.second }); setSelection(fonts.indexOfFirst { it.first == prefs.getString("font", "mono") }.coerceAtLeast(0)) }
        box.addView(fs)
        val sizeLabel = tv("Font size: ${prefs.getFloat("font_size", 14f).toInt()} sp", 13f, pal.muted).apply { setPadding(0, dp(10), 0, 0) }
        box.addView(sizeLabel)
        var size = prefs.getFloat("font_size", 14f)
        box.addView(SeekBar(this).apply { max = 20; progress = (size - 8).toInt(); contentDescription = "Font size"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { size = (v + 8).toFloat(); sizeLabel.text = "Font size: ${size.toInt()} sp" }
                override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
            }) })
        box.addView(tv("LIA integration — pairing token", 13f, pal.muted).apply { setPadding(0, dp(14), 0, 0) })
        val tokView = tv(LiaApi.token(), 12f, pal.text).apply { typeface = Typeface.MONOSPACE; setTextIsSelectable(true) }
        box.addView(tokView)
        val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tr.addView(button("Copy token", "Copy token", pal.panel2) { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("LIA token", LiaApi.token())); toast("Copied") })
        tr.addView(button("Regenerate", "Regenerate token", pal.panel2) { tokView.text = LiaApi.regenerateToken(); toast("New token – update LIA AI") })
        box.addView(tr)
        AlertDialog.Builder(this).setTitle("Settings").setView(ScrollView(this).apply { addView(wrap(box)) }).setPositiveButton("Apply") { _, _ ->
            saveCurrentIfDirty()
            prefs.edit().putString("theme", if (th.selectedItemPosition == 0) "dark" else "light").putString("font", fonts[fs.selectedItemPosition].first).putFloat("font_size", size).apply()
            persistSession(); recreate()
        }.setNegativeButton("Cancel", null).show()
    }

    companion object { const val PREVIEW_HOST = "appassets.androidplatform.net" }
}
