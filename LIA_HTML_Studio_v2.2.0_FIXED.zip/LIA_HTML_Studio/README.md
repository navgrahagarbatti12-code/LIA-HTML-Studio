# LIA HTML Studio 2.1.0

A standalone native Android IDE for **HTML websites and HTML5 games**. CSS and JavaScript are supported because they are essential parts of web projects. JSON is supported for web-app configuration files. This project is separate from LIA AI; it does not replace or modify the LIA AI app.

## Supported editor file types

- HTML / HTM: syntax highlighting, HTML tag auto-close, structural validation
- CSS: syntax highlighting, bracket/comment validation, formatter
- JavaScript / MJS: syntax highlighting, bracket/comment validation, runtime console errors in Preview
- JSON / Web Manifest: syntax highlighting and JSON parsing validation
- SVG: opened using the HTML-style editor/highlighter
- Other project assets (images, fonts, audio, etc.) can be imported and referenced by HTML/CSS/JS. Non-web programming languages are not offered as editor modes or templates.

## Included capabilities

### Editing
- Monospaced editor with line-number gutter
- HTML/CSS/JavaScript/JSON syntax highlighting, including embedded `<style>` and `<script>` blocks in HTML
- Automatic closing HTML tags when typing `>` (void tags such as `img`, `br`, and `input` are excluded)
- Auto-close brackets and quotes, auto-indent, bracket matching
- Undo/redo, find/replace, go-to-line, basic formatter, error-line highlighting
- Multiple open file tabs, autosave and draft recovery
- Dark/light themes, font size and font-family settings

### Projects and files
- Create/open/rename/delete projects and files
- Project explorer, folders, project-wide search
- Import ZIP, import folders/files through Android Storage Access Framework, export ZIP
- Project backups and restore
- Safe project-relative path validation and guarded ZIP extraction

### Preview and diagnostics
- WebView preview for multi-file HTML/CSS/JS projects and relative assets
- Mobile and desktop preview modes
- JavaScript console capture, runtime errors, failed resource / 404 reporting
- Static HTML tag, CSS/JS bracket/comment, and JSON validation
- English and Hindi/Hinglish-friendly error explanations
- External navigation is not automatically opened inside the preview

### LIA AI integration
- Dedicated LIA integration API v2 through the ContentProvider and explicit Intent bridge
- Pairing-token authentication, project/file commands, targeted patch operations, change history and undo
- Destructive operations require user approval
- Backwards-compatible explicit actions: `NEW_PROJECT`, `INSERT_CODE`, `REPLACE_ALL`, `RUN_PREVIEW`
- LIA AI integration remains optional; HTML Studio works as a standalone app

## Not implemented / limitations

- Code folding and multi-cursor editing
- Git integration
- Full JavaScript parser, ESLint, TypeScript compiler or breakpoint debugger
- JavaScript syntax errors are reliably surfaced when the preview executes; the static checker currently checks bracket/string/comment balance, not full JavaScript grammar
- No built-in Python, Java, Kotlin or other non-web language execution
- WebView preview executes project JavaScript. Only run projects you trust.
- Android file access is user-granted through Storage Access Framework; the app does not silently browse arbitrary storage.

## Build on GitHub Actions

The workflow uses JDK 17, Android SDK, Gradle 8.9 and Android Gradle Plugin 8.7.3, then runs:

```bash
gradle --no-daemon :app:assembleDebug --stacktrace
```

Push this project to a GitHub repository and run **Actions → Build LIA HTML Studio APK**. Download the `LIA-HTML-Studio-debug-v2.1.0` artifact after the workflow succeeds. The source ZIP does not contain a prebuilt APK or Gradle wrapper.

## Important verification note

The source and workflow have been updated, but a real Android Gradle build, APK installation, WebView preview, Storage Access Framework flows and LIA-to-IDE bridge must still be verified by a successful GitHub Actions run and on-device testing. Do not treat an uploaded APK as verified until those tests pass.


## Version 2.2.0 fixes

- Run and manual refresh now load the selected HTML entry with a unique cache-busting query parameter, avoiding stale top-level preview documents.
- Added a preview screenshot action in the top toolbar and overflow menu. On Android 10+, PNG screenshots are saved to Gallery under Pictures/LIA HTML Studio; on older Android versions they are saved in the app-specific Pictures folder.
- Screenshot capture requires a project preview to be running and the Preview or Split view to be visible.
